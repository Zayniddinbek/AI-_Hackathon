import { createFileRoute } from "@tanstack/react-router";
import ChemistryLab3D from "@/components/lab/ChemistryLab3D";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Kimyo Lab 3D — haqiqiy 3D virtual laboratoriya" },
      {
        name: "description",
        content:
          "Brauzerda ishlaydigan 3D kimyo laboratoriyasi: shisha idishlar, gorelka, qaynash, quyish va haqiqiy reaksiyalar simulyatsiyasi.",
      },
      { property: "og:title", content: "Kimyo Lab 3D — haqiqiy 3D virtual laboratoriya" },
      {
        property: "og:description",
        content:
          "Idishlarni sudrab quying, gorelkani yoqing, neytrallanish, cho'kma va portlashlarni 3D da kuzating.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ChemistryLab3D,
});
