import { useCallback, useEffect, useRef, useState } from "react";
import { CHEMS, getChem, type Chem } from "@/lib/lab/chemistry";
import { LabEngine, type LabSnapshot, type VesselType } from "@/lib/lab/engine";

interface LogLine {
  id: number;
  msg: string;
  kind: string;
  time: string;
}

const EQUIPMENT: { type: VesselType; label: string; icon: string; vol: string }[] = [
  { type: "beaker", label: "Stakan", icon: "🥃", vol: "300ml" },
  { type: "flask", label: "Kolba", icon: "⚗️", vol: "250ml" },
  { type: "test_tube", label: "Probirka", icon: "🧪", vol: "120ml" },
  { type: "cylinder", label: "Silindr", icon: "📏", vol: "190ml" },
];

function phTone(pH: number) {
  if (pH <= 3) return "text-lab-acid";
  if (pH >= 10) return "text-lab-base";
  return "text-lab-neutral";
}

export default function ChemistryLab3D() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<LabEngine | null>(null);
  const logIdRef = useRef(0);
  const [snap, setSnap] = useState<LabSnapshot>({
    vessels: [],
    selId: null,
    burnerOn: false,
    burnerTemp: 500,
    spills: 0,
  });
  const [logs, setLogs] = useState<LogLine[]>([]);
  const [pour, setPour] = useState<{ srcId: string; tgtId: string; amount: number } | null>(null);
  const [panel, setPanel] = useState<"tools" | "info" | null>(null);
  const [showFormulas, setShowFormulas] = useState(false);

  const pushLog = useCallback((msg: string, kind = "i") => {
    setLogs((prev) =>
      [{ id: ++logIdRef.current, msg, kind, time: new Date().toLocaleTimeString() }, ...prev].slice(
        0,
        60,
      ),
    );
  }, []);

  useEffect(() => {
    if (!mountRef.current) return;
    const engine = new LabEngine(mountRef.current, {
      onState: setSnap,
      onLog: (msg, kind) => pushLog(msg, kind ?? "i"),
      onPourRequest: (srcId, tgtId) => setPour({ srcId, tgtId, amount: 50 }),
    });
    engineRef.current = engine;
    if (import.meta.env.DEV) (window as unknown as Record<string, unknown>)["__lab"] = engine;
    engine.addVessel("beaker", "h2o", "Suv");
    engine.addVessel("flask", "hcl", "HCl");
    engine.addVessel("test_tube", "naoh", "NaOH");
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, [pushLog]);

  const sel = snap.vessels.find((v) => v.id === snap.selId) ?? null;
  const selChem = sel ? getChem(sel.chemId) : null;
  const src = pour ? snap.vessels.find((v) => v.id === pour.srcId) : null;

  const addChem = (c: Chem, type: VesselType = "beaker") =>
    engineRef.current?.addVessel(type, c.id, c.f);

  return (
    <div className="relative flex h-screen w-full overflow-hidden bg-background text-foreground">
      {/* ---------- Mobile drawer scrim ---------- */}
      {panel && (
        <button
          aria-label="Menyuni yopish"
          onClick={() => setPanel(null)}
          className="fixed inset-0 z-30 bg-background/60 backdrop-blur-sm lg:hidden"
        />
      )}

      {/* ---------- Left: equipment + reagents (side drawer on mobile) ---------- */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-60 shrink-0 flex-col gap-3 overflow-y-auto border-r border-border/60 bg-card p-3 shadow-2xl transition-transform duration-300 lg:static lg:z-0 lg:h-full lg:w-64 lg:translate-x-0 lg:bg-card/70 lg:shadow-none ${
          panel === "tools" ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between">
          <h1 className="font-display text-sm font-bold tracking-[0.2em] text-lab-accent uppercase">
            Kimyo Lab 3D
          </h1>
        </div>

        <section>
          <h2 className="lab-section">Idishlar</h2>
          <div className="grid grid-cols-2 gap-2">
            {EQUIPMENT.map((e) => (
              <button
                key={e.type}
                onClick={() => engineRef.current?.addVessel(e.type, null, e.label)}
                className="lab-tile"
              >
                <span className="text-lg leading-none">{e.icon}</span>
                <span className="font-semibold">{e.label}</span>
                <span className="text-[9px] text-muted-foreground">{e.vol}</span>
              </button>
            ))}
          </div>
        </section>

        <section className="flex-1 space-y-3">
          <h2 className="lab-section">Reaktivlar</h2>
          {(
            [
              ["Kislotalar", CHEMS.acids],
              ["Ishqorlar", CHEMS.bases],
              ["Boshqalar", CHEMS.others],
            ] as const
          ).map(([title, list]) => (
            <div key={title}>
              <p className="mb-1 text-[9px] font-semibold tracking-widest text-muted-foreground uppercase">
                {title}
              </p>
              <div className="grid grid-cols-2 gap-1.5">
                {list.map((c) => (
                  <button key={c.id} onClick={() => addChem(c)} className="lab-chem" title={c.n}>
                    <span
                      className="lab-dot"
                      style={{ backgroundColor: c.color, boxShadow: `0 0 8px ${c.color}` }}
                    />
                    <span className="truncate font-semibold">{c.f}</span>
                    <span className="ml-auto text-[8px] text-muted-foreground">{c.cat}</span>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </section>

        <div className="mt-auto flex flex-col gap-2 pt-2 border-t border-border/40">
          <button onClick={() => setShowFormulas(true)} className="lab-btn-ghost w-full">
            📋 Formulalar jadvali
          </button>
          <button onClick={() => engineRef.current?.reset()} className="lab-btn-danger">
            ✕ Stolni tozalash{snap.spills ? ` (${snap.spills} dog')` : ""}
          </button>
        </div>
      </aside>

      {/* ---------- Center: 3D viewport ---------- */}
      <main className="relative h-full flex-1 touch-none select-none">
        <div ref={mountRef} className="absolute inset-0 touch-none select-none" />

        {/* mobile panel triggers, docked to the screen sides */}
        <div className="absolute top-3 left-3 z-20 flex flex-col gap-2 lg:hidden">
          <button
            onClick={() => setPanel("tools")}
            className="lab-btn-primary !flex-none px-3 py-2"
          >
            ☰ Menyu
          </button>
        </div>
        <div className="absolute top-3 right-3 z-20 flex flex-col gap-2 lg:hidden">
          <button
            onClick={() => setPanel("info")}
            className="lab-btn-ghost bg-card/80 px-3 py-2 backdrop-blur"
          >
            📊 Tahlil
          </button>
        </div>
      </main>

      {/* ---------- Right: analysis + burner + log (side drawer on mobile) ---------- */}
      <aside
        className={`fixed inset-y-0 right-0 z-40 flex w-64 shrink-0 flex-col gap-3 overflow-y-auto border-l border-border/60 bg-card p-3 shadow-2xl transition-transform duration-300 lg:static lg:z-0 lg:h-full lg:w-72 lg:translate-x-0 lg:bg-card/70 lg:shadow-none ${
          panel === "info" ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* Gorelka Section relocated to right sidebar */}
        <section className="rounded-lg border border-border/60 bg-background/50 p-2.5">
          <div className="flex items-center justify-between mb-1.5">
            <h2 className="lab-section !mb-0">Gorelka</h2>
            <span className="text-[10px] text-muted-foreground">
              Alanga: <b className="text-lab-hot">{snap.burnerTemp}°C</b>
            </span>
          </div>
          <button
            onClick={() => engineRef.current?.toggleBurner()}
            className={`w-full py-1.5 px-3 rounded-lg text-xs font-semibold transition-all ${
              snap.burnerOn
                ? "bg-amber-500/20 text-amber-400 border border-amber-500/40 shadow-[0_0_12px_rgba(245,158,11,0.25)]"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {snap.burnerOn ? "🔥 Gorelka yoniq" : "Gorelkani yoqish"}
          </button>
          <input
            type="range"
            min={60}
            max={1200}
            step={10}
            value={snap.burnerTemp}
            onChange={(e) => engineRef.current?.setBurnerTemp(Number(e.target.value))}
            className="mt-2.5 w-full accent-lab-hot"
          />
          <div className="mt-1 flex gap-1">
            {[100, 300, 500, 900].map((t) => (
              <button
                key={t}
                onClick={() => engineRef.current?.setBurnerTemp(t)}
                className={`lab-btn-ghost flex-1 !px-1 !py-0.5 text-[9px] ${
                  snap.burnerTemp === t ? "!border-lab-hot text-lab-hot font-bold" : ""
                }`}
              >
                {t}°
              </button>
            ))}
          </div>
        </section>

        <section>
          <h2 className="lab-section">Tahlil</h2>
          {!sel ? (
            <p className="text-[10px] text-muted-foreground">Idishni bosib tanlang.</p>
          ) : (
            <div className="space-y-2 rounded-lg border border-border/60 bg-background/50 p-3">
              <p className="font-display text-xs font-bold text-lab-accent">{sel.label}</p>
              <p className="text-[10px] text-muted-foreground">
                {selChem ? selChem.n : "Aralashma / mahsulot"} · {sel.type}
              </p>
              <div className="grid grid-cols-2 gap-2 text-[10px]">
                <div className="lab-stat">
                  <span>Hajm</span>
                  <b>
                    {sel.vol.toFixed(0)}/{sel.maxVol}ml
                  </b>
                </div>
                <div className="lab-stat">
                  <span>pH</span>
                  <b className={phTone(sel.pH)}>{sel.pH.toFixed(1)}</b>
                </div>
                <div className="lab-stat">
                  <span>Harorat</span>
                  <b className={sel.temp > 80 ? "text-lab-hot" : ""}>{sel.temp.toFixed(0)}°C</b>
                </div>
                <div className="lab-stat">
                  <span>Holat</span>
                  <b>{sel.boiling ? "Qaynayapti" : sel.vol > 0.5 ? "Suyuq" : "Bo'sh"}</b>
                </div>
              </div>
              <div className="h-1.5 overflow-hidden rounded-full bg-muted">
                <div
                  className="h-full rounded-full bg-lab-accent transition-all"
                  style={{ width: `${Math.min(100, (sel.vol / sel.maxVol) * 100)}%` }}
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() =>
                    setPour({
                      srcId: sel.id,
                      tgtId: snap.vessels.find((v) => v.id !== sel.id)?.id ?? "",
                      amount: Math.min(50, Math.floor(sel.vol)),
                    })
                  }
                  disabled={sel.vol <= 0.5 || snap.vessels.length < 2}
                  className="lab-btn-primary flex-1"
                >
                  Quyish
                </button>
                <button
                  onClick={() => engineRef.current?.removeVessel(sel.id)}
                  className="lab-btn-danger flex-1"
                >
                  Olib tashlash
                </button>
              </div>
            </div>
          )}
        </section>

        <section className="flex min-h-40 flex-1 flex-col">
          <h2 className="lab-section">Jurnal</h2>
          <div className="flex-1 space-y-1 overflow-y-auto rounded-lg border border-border/60 bg-background/50 p-2 font-mono text-[9px] leading-relaxed">
            {logs.length === 0 && <p className="text-muted-foreground">Hodisalar shu yerda…</p>}
            {logs.map((l) => (
              <p
                key={l.id}
                className={
                  l.kind === "e"
                    ? "text-lab-hot"
                    : l.kind === "s"
                      ? "text-lab-base"
                      : l.kind === "w"
                        ? "text-lab-warn"
                        : "text-muted-foreground"
                }
              >
                <span className="opacity-50">[{l.time}]</span> {l.msg}
              </p>
            ))}
          </div>
        </section>
      </aside>

      {/* ---------- Pour dialog with Slider + Direct Number Input ---------- */}
      {pour && src && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/70 p-4 backdrop-blur-sm">
          <div className="w-full max-w-xs space-y-3.5 rounded-xl border border-lab-accent/30 bg-card p-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-sm font-bold text-lab-accent">Suyuqlik quyish</h3>
              <span className="text-[10px] text-muted-foreground">
                Mavjud: <b className="text-foreground">{src.vol.toFixed(0)}ml</b>
              </span>
            </div>

            <label className="block text-[10px] text-muted-foreground">
              Qaysi idishga
              <select
                value={pour.tgtId}
                onChange={(e) => setPour({ ...pour, tgtId: e.target.value })}
                className="lab-input mt-1"
              >
                {snap.vessels
                  .filter((v) => v.id !== pour.srcId)
                  .map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.label} · {v.vol.toFixed(0)}/{v.maxVol}ml
                    </option>
                  ))}
              </select>
            </label>

            <div className="space-y-1.5 rounded-lg border border-border/60 bg-background/40 p-2.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-muted-foreground">Quyiladigan miqdor:</span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min={1}
                    max={Math.max(1, Math.floor(src.vol))}
                    value={pour.amount}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      if (!isNaN(val)) {
                        setPour({
                          ...pour,
                          amount: Math.max(1, Math.min(Math.floor(src.vol), val)),
                        });
                      }
                    }}
                    className="w-16 rounded border border-border bg-background px-2 py-0.5 text-right font-mono text-xs font-bold text-foreground focus:border-lab-accent focus:outline-none"
                  />
                  <span className="font-bold text-xs text-muted-foreground">ml</span>
                </div>
              </div>

              <input
                type="range"
                min={1}
                max={Math.max(1, Math.floor(src.vol))}
                step={1}
                value={pour.amount}
                onChange={(e) => setPour({ ...pour, amount: Number(e.target.value) })}
                className="w-full accent-lab-accent cursor-pointer"
              />

              <div className="flex gap-1 pt-1">
                {[
                  { label: "25ml", val: 25 },
                  { label: "50ml", val: 50 },
                  { label: "100ml", val: 100 },
                  { label: "Barchasi", val: Math.floor(src.vol) },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() =>
                      setPour({
                        ...pour,
                        amount: Math.max(1, Math.min(Math.floor(src.vol), preset.val)),
                      })
                    }
                    className={`lab-btn-ghost flex-1 !px-1 !py-1 text-[9px] ${
                      pour.amount === preset.val
                        ? "!border-lab-accent text-lab-accent font-bold"
                        : ""
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-2 pt-1">
              <button
                onClick={() => {
                  if (pour.tgtId) engineRef.current?.pour(pour.srcId, pour.tgtId, pour.amount);
                  setPour(null);
                }}
                className="lab-btn-primary flex-1"
              >
                Quyish
              </button>
              <button
                onClick={() => {
                  engineRef.current?.cancelPour(pour.srcId);
                  setPour(null);
                }}
                className="lab-btn-ghost flex-1"
              >
                Bekor
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------- Full Chemical Reactions & Formulas Guide Modal ---------- */}
      {showFormulas && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-4 backdrop-blur-md">
          <div className="flex max-h-[90vh] w-full max-w-2xl flex-col rounded-2xl border border-border/80 bg-card shadow-2xl">
            <div className="flex items-center justify-between border-b border-border/60 p-4">
              <div className="flex items-center gap-2">
                <span className="text-xl">🧪</span>
                <div>
                  <h3 className="font-display text-base font-bold text-lab-accent">
                    Kimyoviy Formulalar va Reaksiyalar Jadvali
                  </h3>
                  <p className="text-[11px] text-muted-foreground">
                    Doskadagi barcha reaksiyalar va qonuniyatlar
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowFormulas(false)}
                className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                aria-label="Yopish"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 space-y-4 overflow-y-auto p-4 text-xs">
              {/* Category 1 */}
              <div className="rounded-xl border border-border/60 bg-background/50 p-3.5">
                <h4 className="font-semibold text-emerald-400">
                  ① Neytrallanish va Kislota-Ishqor Reaksiyalari
                </h4>
                <ul className="mt-2 space-y-1 font-mono text-[11px] text-muted-foreground">
                  <li className="text-foreground">· HCl + NaOH → NaCl + H₂O (ΔH = -57 kJ/mol)</li>
                  <li className="text-foreground">
                    · H₂SO₄ + 2NaOH → Na₂SO₄ + 2H₂O (ΔH = -114 kJ/mol)
                  </li>
                  <li className="text-foreground">· HCl + KOH → KCl + H₂O</li>
                  <li className="text-foreground">· H₂SO₄ + 2KOH → K₂SO₄ + 2H₂O</li>
                  <li className="text-foreground">· 2HCl + Ca(OH)₂ → CaCl₂ + 2H₂O</li>
                  <li className="text-foreground">· NH₃ + HCl → NH₄Cl (Oq tutun)</li>
                  <li className="text-foreground">
                    · H₂SO₄ + H₂O → H₂SO₄(suyultirilgan) + Issiqlik
                  </li>
                </ul>
              </div>

              {/* Category 2 */}
              <div className="rounded-xl border border-border/60 bg-background/50 p-3.5">
                <h4 className="font-semibold text-orange-400">
                  ② Metallarning Faol Reaksiyalari (Portlash va Gaz)
                </h4>
                <ul className="mt-2 space-y-1 font-mono text-[11px] text-muted-foreground">
                  <li className="text-foreground">· 2Na + 2H₂O → 2NaOH + H₂↑ (Portlash!)</li>
                  <li className="text-foreground">
                    · 2K + 2H₂O → 2KOH + H₂↑ (O'ta kuchli ekzotermik!)
                  </li>
                  <li className="text-foreground">· 2Na + 2HCl → 2NaCl + H₂↑</li>
                  <li className="text-foreground">· 2K + 2HCl → 2KCl + H₂↑ (Mega portlash)</li>
                  <li className="text-foreground">· 2Na + H₂SO₄ → Na₂SO₄ + H₂↑</li>
                </ul>
              </div>

              {/* Category 3 */}
              <div className="rounded-xl border border-border/60 bg-background/50 p-3.5">
                <h4 className="font-semibold text-sky-400">③ Cho'kma va Oksidlanish-Qaytarilish</h4>
                <ul className="mt-2 space-y-1 font-mono text-[11px] text-muted-foreground">
                  <li className="text-foreground">
                    · CuSO₄ + 2NaOH → Cu(OH)₂↓ + Na₂SO₄ (Ko'k cho'kma)
                  </li>
                  <li className="text-foreground">
                    · FeCl₃ + 3NaOH → Fe(OH)₃↓ + 3NaCl (Qo'ng'ir cho'kma)
                  </li>
                  <li className="text-foreground">
                    · CuSO₄ + 4NH₃ → [Cu(NH₃)₄]SO₄ (To'q ko'k kompleks)
                  </li>
                  <li className="text-foreground">· 2H₂O₂ → 2H₂O + O₂↑ (Katalizator: FeCl₃)</li>
                  <li className="text-foreground">· H₂O₂ + KMnO₄ → O₂↑ + MnO₂↓ + H₂O</li>
                  <li className="text-foreground">· C₂H₅OH + H₂SO₄ → Efirlashish + Issiqlik</li>
                  <li className="text-foreground">· C₂H₅OH + KMnO₄ → Oksidlanish</li>
                </ul>
              </div>

              {/* Category 4 */}
              <div className="rounded-xl border border-border/60 bg-background/50 p-3.5">
                <h4 className="font-semibold text-purple-400">
                  ④ Indikatorlar va pH Rang Shkalasi
                </h4>
                <div className="mt-2 space-y-1.5 text-[11px]">
                  <p>
                    <b className="text-foreground">Lakmus:</b> pH &lt; 6.5 (
                    <span className="text-red-400 font-semibold">Qizil</span>), pH 7 (
                    <span className="text-purple-400 font-semibold">Binafsha</span>), pH &gt; 7.5 (
                    <span className="text-blue-400 font-semibold">Ko'k</span>)
                  </p>
                  <p>
                    <b className="text-foreground">Fenolftalein:</b> pH ≤ 8.2 (
                    <span className="text-zinc-300 font-semibold">Rangsiz</span>), pH &gt; 8.2 (
                    <span className="text-pink-400 font-semibold">Yorqin pushti / malina</span>)
                  </p>
                  <p className="text-muted-foreground">
                    <b className="text-foreground">Gorelka:</b> Idishni 100°C+ qizdirganda suyuqlik
                    qaynaydi va bug' ajraladi. Bo'sh idish 480°C+ ga yetsa termik zarbadan sinadi.
                  </p>
                </div>
              </div>
            </div>

            <div className="border-t border-border/60 p-4">
              <button onClick={() => setShowFormulas(false)} className="lab-btn-primary w-full">
                Tushundim
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
