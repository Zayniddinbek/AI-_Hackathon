export { ChemistryLab3D } from "./ChemistryLab3D";
