export type ChemType =
  "acid" | "base" | "indicator" | "salt" | "metal" | "water" | "oxidizer" | "organic";

export interface Chem {
  id: string;
  f: string;
  n: string;
  color: string;
  pH: number;
  cat: string;
  type: ChemType;
  density: number;
  boil: number;
}

export interface Rxn {
  r1: string;
  r2: string;
  type: string;
  eq: string;
  lc: string;
  pH: number;
  eff: string;
  note: string;
  heat: number;
  big?: boolean;
}

/** Toza suv kabi rangsiz eritmalar uchun shaffof ko'k-moviy tiniq rang. */
export const CLEAR = "#bde4f7";

export const CHEMS: Record<"acids" | "bases" | "others", Chem[]> = {
  acids: [
    // Kislotalarning suvdagi eritmalari toza tabiatda rangsiz
    {
      id: "hcl",
      f: "HCl",
      n: "Xlorid kislota",
      color: CLEAR,
      pH: 1,
      cat: "K",
      type: "acid",
      density: 1.19,
      boil: 110,
    },
    {
      id: "h2so4",
      f: "H₂SO₄",
      n: "Sulfat kislota",
      color: "#b0def5",
      pH: 0.5,
      cat: "K",
      type: "acid",
      density: 1.84,
      boil: 337,
    },
    {
      id: "hno3",
      f: "HNO₃",
      n: "Nitrat kislota",
      color: "#e6ecc8",
      pH: 1,
      cat: "K",
      type: "acid",
      density: 1.51,
      boil: 86,
    },
    {
      id: "hclo4",
      f: "HClO₄",
      n: "Perxlor kislota",
      color: CLEAR,
      pH: 0,
      cat: "K",
      type: "acid",
      density: 1.77,
      boil: 203,
    },
  ],
  bases: [
    // Ishqorlarning suvdagi eritmalari ham rangsiz
    {
      id: "naoh",
      f: "NaOH",
      n: "Natriy gidroksid",
      color: CLEAR,
      pH: 13,
      cat: "I",
      type: "base",
      density: 2.13,
      boil: 1390,
    },
    {
      id: "koh",
      f: "KOH",
      n: "Kaliy gidroksid",
      color: CLEAR,
      pH: 13,
      cat: "I",
      type: "base",
      density: 2.04,
      boil: 1327,
    },
    {
      id: "caoh2",
      f: "Ca(OH)₂",
      n: "Kaltsiy gidroksid",
      color: "#e2eff7",
      pH: 12,
      cat: "I",
      type: "base",
      density: 2.21,
      boil: 580,
    },
    {
      id: "nh3",
      f: "NH₃",
      n: "Ammiak eritmasi",
      color: CLEAR,
      pH: 11,
      cat: "I",
      type: "base",
      density: 0.9,
      boil: 38,
    },
  ],
  others: [
    // Fenolftalein: kislotali/neytral muhitda rangsiz
    {
      id: "phenol",
      f: "Fenolftalein",
      n: "Indikator",
      color: CLEAR,
      pH: 7,
      cat: "IND",
      type: "indicator",
      density: 1,
      boil: 100,
    },
    // Lakmus: neytral holatda to'q binafsha
    {
      id: "litmus",
      f: "Lakmus",
      n: "Indikator",
      color: "#7c3aed",
      pH: 7,
      cat: "IND",
      type: "indicator",
      density: 1,
      boil: 100,
    },
    // Gidratlangan Cu²⁺ ionlari — yorqin osmon ko'k eritma
    {
      id: "cuso4",
      f: "CuSO₄",
      n: "Mis(II) sulfat",
      color: "#1d70e8",
      pH: 4,
      cat: "TUZ",
      type: "salt",
      density: 3.6,
      boil: 150,
    },
    // Fe³⁺ ionlari — oltinsimon sarg'ish-jigarrang eritma
    {
      id: "fecl3",
      f: "FeCl₃",
      n: "Temir(III) xlorid",
      color: "#c26a15",
      pH: 3,
      cat: "TUZ",
      type: "salt",
      density: 2.9,
      boil: 316,
    },
    // MnO₄⁻ ionlari — to'q binafsha (siyohrang) eritma
    {
      id: "kmno4",
      f: "KMnO₄",
      n: "Kaliy permanganat",
      color: "#6b1275",
      pH: 7,
      cat: "TUZ",
      type: "salt",
      density: 2.7,
      boil: 240,
    },
    {
      id: "na_metal",
      f: "Na",
      n: "Natriy metall",
      color: "#ccd5de",
      pH: 7,
      cat: "ME",
      type: "metal",
      density: 0.97,
      boil: 883,
    },
    {
      id: "k_metal",
      f: "K",
      n: "Kaliy metall",
      color: "#bcc6d1",
      pH: 7,
      cat: "ME",
      type: "metal",
      density: 0.89,
      boil: 759,
    },
    {
      id: "h2o",
      f: "H₂O",
      n: "Suv",
      color: "#8dcbf5",
      pH: 7,
      cat: "SV",
      type: "water",
      density: 1,
      boil: 100,
    },
    {
      id: "h2o2",
      f: "H₂O₂",
      n: "Vodorod peroksid",
      color: CLEAR,
      pH: 6,
      cat: "OK",
      type: "oxidizer",
      density: 1.45,
      boil: 150,
    },
    {
      id: "ethanol",
      f: "C₂H₅OH",
      n: "Etanol (spirt)",
      color: "#dcedf7",
      pH: 7,
      cat: "OR",
      type: "organic",
      density: 0.79,
      boil: 78,
    },
  ],
};

export const REACTIONS: Rxn[] = [
  {
    r1: "hcl",
    r2: "naoh",
    type: "Neytrallanish",
    eq: "HCl + NaOH → NaCl + H₂O",
    lc: "#bde4f7",
    pH: 7,
    eff: "bubble",
    note: "Neytrallanish — NaCl + H₂O! ΔH=-57kJ/mol",
    heat: 25,
  },
  {
    r1: "hcl",
    r2: "koh",
    type: "Neytrallanish",
    eq: "HCl + KOH → KCl + H₂O",
    lc: "#bde4f7",
    pH: 7,
    eff: "bubble",
    note: "Neytrallanish reaksiyasi!",
    heat: 18,
  },
  {
    r1: "h2so4",
    r2: "naoh",
    type: "Neytrallanish",
    eq: "H₂SO₄+2NaOH→Na₂SO₄+2H₂O",
    lc: "#bde4f7",
    pH: 7,
    eff: "bubble+smoke",
    note: "Kuchli ekzotermik! ΔH=-114kJ/mol",
    heat: 70,
  },
  {
    r1: "h2so4",
    r2: "koh",
    type: "Neytrallanish",
    eq: "H₂SO₄+2KOH→K₂SO₄+2H₂O",
    lc: "#bde4f7",
    pH: 7,
    eff: "bubble+smoke",
    note: "Kuchli neytrallanish!",
    heat: 65,
  },
  {
    r1: "hcl",
    r2: "caoh2",
    type: "Neytrallanish",
    eq: "2HCl+Ca(OH)₂→CaCl₂+2H₂O",
    lc: "#dbe8f5",
    pH: 7,
    eff: "bubble",
    note: "Kalsiy xlorid hosil bo'ldi!",
    heat: 12,
  },
  // Indikatorlar alohida REACTIONS yozuvlariga ega emas — ularning rangi
  // aralashmaning real pH qiymatiga qarab indicatorColor() orqali aniqlanadi.
  {
    r1: "na_metal",
    r2: "h2o",
    type: "⚠ PORTLASH",
    eq: "2Na+2H₂O→2NaOH+H₂↑",
    lc: "#f97316",
    pH: 13,
    eff: "explosion",
    note: "⚠️ XAVFLI! Kuchli portlash!",
    heat: 500,
    big: true,
  },
  {
    r1: "k_metal",
    r2: "h2o",
    type: "⚠ KUCHLI PORTLASH",
    eq: "2K+2H₂O→2KOH+H₂↑",
    lc: "#a855f7",
    pH: 14,
    eff: "mega_explosion",
    note: "💥 O'ta xavfli! Kaliy suv bilan — KUCHLI PORTLASH!",
    heat: 800,
    big: true,
  },
  {
    r1: "k_metal",
    r2: "hcl",
    type: "⚠ MEGA PORTLASH",
    eq: "2K+2HCl→2KCl+H₂↑",
    lc: "#c084fc",
    pH: 7,
    eff: "mega_explosion",
    note: "💥💥 MEGA PORTLASH! Kaliy+Kislota!",
    heat: 1000,
    big: true,
  },
  {
    r1: "na_metal",
    r2: "hcl",
    type: "⚠ PORTLASH",
    eq: "2Na+2HCl→2NaCl+H₂↑",
    lc: "#fb923c",
    pH: 7,
    eff: "explosion",
    note: "⚠️ Portlash! Metall + kislota!",
    heat: 600,
    big: true,
  },
  {
    r1: "na_metal",
    r2: "h2so4",
    type: "⚠ KUCHLI PORTLASH",
    eq: "2Na+H₂SO₄→Na₂SO₄+H₂↑",
    lc: "#ea580c",
    pH: 7,
    eff: "mega_explosion",
    note: "💥 Natriy sulfat kislota bilan!",
    heat: 700,
    big: true,
  },
  {
    r1: "k_metal",
    r2: "h2so4",
    type: "⚠ MEGA PORTLASH",
    eq: "2K+H₂SO₄→K₂SO₄+H₂↑",
    lc: "#c084fc",
    pH: 7,
    eff: "mega_explosion",
    note: "💥💥 O'TA KUCHLI MEGA PORTLASH! Kaliy + Sulfat kislota!",
    heat: 1200,
    big: true,
  },
  {
    r1: "k_metal",
    r2: "hno3",
    type: "⚠ MEGA PORTLASH",
    eq: "K+HNO₃→KNO₃+NO₂↑+H₂O",
    lc: "#a855f7",
    pH: 7,
    eff: "mega_explosion",
    note: "💥💥 MEGA PORTLASH! Kaliy + Nitrat kislota!",
    heat: 1100,
    big: true,
  },
  {
    r1: "na_metal",
    r2: "hno3",
    type: "⚠ MEGA PORTLASH",
    eq: "Na+HNO₃→NaNO₃+NO₂↑+H₂O",
    lc: "#f97316",
    pH: 7,
    eff: "mega_explosion",
    note: "💥 KUCHLI PORTLASH! Natriy + Nitrat kislota!",
    heat: 900,
    big: true,
  },
  {
    r1: "hno3",
    r2: "naoh",
    type: "Neytrallanish",
    eq: "HNO₃+NaOH→NaNO₃+H₂O",
    lc: "#bde4f7",
    pH: 7,
    eff: "bubble",
    note: "Neytrallanish — NaNO₃ + H₂O! ΔH=-57kJ/mol",
    heat: 30,
  },
  {
    r1: "hno3",
    r2: "koh",
    type: "Neytrallanish",
    eq: "HNO₃+KOH→KNO₃+H₂O",
    lc: "#bde4f7",
    pH: 7,
    eff: "bubble",
    note: "Neytrallanish reaksiyasi!",
    heat: 28,
  },
  {
    r1: "ethanol",
    r2: "h2so4",
    type: "Ekzotermik",
    eq: "C₂H₅OH+H₂SO₄→ester",
    lc: "#bde4f7",
    pH: 2,
    eff: "heat+smoke",
    note: "Ekzotermik reaksiya — ester hosil!",
    heat: 80,
  },
  {
    r1: "ethanol",
    r2: "kmno4",
    type: "Oksidlanish",
    eq: "C₂H₅OH+KMnO₄→oksidlanish",
    lc: "#784c08",
    pH: 5,
    eff: "color+bubble",
    note: "Spirt oksidlanishi!",
    heat: 30,
  },
  {
    r1: "cuso4",
    r2: "naoh",
    type: "Cho'kma",
    eq: "CuSO₄+2NaOH→Cu(OH)₂↓+Na₂SO₄",
    lc: "#0284c7",
    pH: 9,
    eff: "precipitate",
    note: "Yorqin moviy cho'kma: Cu(OH)₂!",
    heat: 5,
  },
  {
    r1: "fecl3",
    r2: "naoh",
    type: "Cho'kma",
    eq: "FeCl₃+3NaOH→Fe(OH)₃↓+3NaCl",
    lc: "#9a3412",
    pH: 9,
    eff: "precipitate",
    note: "Qo'ng'ir-jigarrang cho'kma: Fe(OH)₃!",
    heat: 5,
  },
  {
    r1: "kmno4",
    r2: "h2so4",
    type: "Oksidlanish",
    eq: "2KMnO₄+H₂SO₄→oksidlanish",
    lc: "#4c0559",
    pH: 2,
    eff: "color+smoke+bubble",
    note: "Kuchli oksidlovchi reaksiya!",
    heat: 30,
  },
  {
    r1: "h2so4",
    r2: "h2o",
    type: "Suyultirish",
    eq: "H₂SO₄+H₂O→suyultirilgan H₂SO₄",
    lc: "#bfe0f5",
    pH: 2,
    eff: "heat+bubble",
    note: "⚠️ Ekzotermik! Kislotani suvga qo'shing!",
    heat: 95,
  },
  {
    r1: "h2o2",
    r2: "kmno4",
    type: "Oksidlanish",
    eq: "H₂O₂+KMnO₄→O₂↑+H₂O",
    lc: "#e8d5f5",
    pH: 7,
    eff: "bubble+smoke",
    note: "Kislorod ajralib chiqadi! O₂↑",
    heat: 40,
  },
  {
    r1: "h2o2",
    r2: "fecl3",
    type: "Kataliz",
    eq: "H₂O₂→H₂O+½O₂↑ (kat:Fe)",
    lc: "#c26a15",
    pH: 6,
    eff: "bubble",
    note: "Fenton reaksiyasi — tez kislorod!",
    heat: 20,
  },
  {
    r1: "nh3",
    r2: "hcl",
    type: "Neytrallanish",
    eq: "NH₃+HCl→NH₄Cl (oq tutun)",
    lc: "#f1f5f9",
    pH: 7,
    eff: "smoke+bubble",
    note: "Ammoniy xlorid — oq tutun!",
    heat: 12,
  },
  {
    r1: "cuso4",
    r2: "nh3",
    type: "Kompleks",
    eq: "CuSO₄+4NH₃→[Cu(NH₃)₄]SO₄",
    lc: "#1e3a8a",
    pH: 10,
    eff: "color",
    note: "Tetraaminomis(II) — to'q sapfir ko'k!",
    heat: 5,
  },
];

export function findRxn(
  a: string | null,
  b: string | null,
  labelA?: string,
  labelB?: string,
): Rxn | null {
  if (!a && !labelA) return null;
  if (!b && !labelB) return null;

  // 1. Direct ID lookup
  if (a && b) {
    const direct = REACTIONS.find((r) => (r.r1 === a && r.r2 === b) || (r.r1 === b && r.r2 === a));
    if (direct) return direct;
  }

  // 2. Mixture / species component lookup from labels
  const matches = (chemId: string, id?: string | null, lbl?: string) => {
    if (id === chemId) return true;
    if (!lbl) return false;
    const c = getChem(chemId);
    if (!c) return false;
    // Check if the label contains this chemical's formula (as a distinct word or term)
    const regex = new RegExp(`(^|[ +,])${c.f.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}($|[ +,])`);
    return regex.test(lbl);
  };

  for (const r of REACTIONS) {
    if (matches(r.r1, a, labelA) && matches(r.r2, b, labelB)) return r;
    if (matches(r.r2, a, labelA) && matches(r.r1, b, labelB)) return r;
  }

  return null;
}

/**
 * Kimyoviy eritmalar aralashganda formulalarni to'g'ri, qisqa va takrorlanmaydigan
 * standart kimyoviy ko'rinishga keltiradi (masalan: "NaCl + NaOH + H₂O").
 */
export function combineChemicalLabels(labelA: string, labelB: string): string {
  if (!labelA) return labelB || "H₂O";
  if (!labelB) return labelA || "H₂O";

  const extractParts = (text: string) => {
    let t = text;
    if (t.includes("→")) {
      t = t.split("→")[1]!.trim();
    }
    // Remove annotations in parentheses
    t = t.replace(/\s*\([^)]*\)/g, "");
    return t
      .split(/\s*\+\s*/)
      .map((s) => s.trim())
      .filter(Boolean);
  };

  const partsA = extractParts(labelA);
  const partsB = extractParts(labelB);

  const seen = new Set<string>();
  const solutes: string[] = [];
  let hasWater = false;

  for (const raw of [...partsA, ...partsB]) {
    const clean = raw.trim();
    if (!clean) continue;

    // Normalizing water representation
    if (
      clean === "H₂O" ||
      clean === "H2O" ||
      clean === "2H₂O" ||
      clean === "3H₂O" ||
      clean.toLowerCase() === "suv"
    ) {
      hasWater = true;
      continue;
    }

    // Clean leading numeric coefficients for display in mixture
    const norm = clean.replace(/^[0-9]+/, "").trim() || clean;
    if (!seen.has(norm)) {
      seen.add(norm);
      solutes.push(norm);
    }
  }

  if (solutes.length === 0) {
    return "H₂O";
  }

  if (hasWater) {
    return `${solutes.join(" + ")} + H₂O`;
  }
  return solutes.join(" + ");
}

/**
 * Indikatorning rangi eritma pH'iga qarab real kimyoviy qoidalar bo'yicha:
 * - Lakmus: kislota (pH<7) — qizil, neytral — binafsha, ishqor (pH>7) — ko'k
 * - Fenolftalein: pH≤8.2 — rangsiz, pH>8.2 — yorqin pushti (malina)
 */
export function indicatorColor(ind: string | null, pH: number): string | null {
  if (ind === "litmus") return pH < 6.5 ? "#dc2626" : pH > 7.5 ? "#1d4ed8" : "#7c3aed";
  if (ind === "phenol") return pH > 8.2 ? "#db2777" : CLEAR;
  return null;
}

export function getChem(id: string | null): Chem | null {
  if (!id) return null;
  for (const g of Object.values(CHEMS)) {
    const c = g.find((x) => x.id === id);
    if (c) return c;
  }
  return null;
}

export function blendHex(c1: string, c2: string): string {
  return blendWeightedHex(c1, c2, 0.5);
}

export function blendWeightedHex(c1: string, c2: string, weight2: number): string {
  const p = (c: string): [number, number, number] => {
    const m = /^#([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(c);
    if (!m) return [160, 205, 240];
    return [parseInt(m[1]!, 16), parseInt(m[2]!, 16), parseInt(m[3]!, 16)];
  };
  const a = p(c1);
  const b = p(c2);
  const w = Math.max(0, Math.min(1, weight2));
  return `#${([0, 1, 2] as const)
    .map((i) =>
      Math.round(a[i] * (1 - w) + b[i] * w)
        .toString(16)
        .padStart(2, "0"),
    )
    .join("")}`;
}
