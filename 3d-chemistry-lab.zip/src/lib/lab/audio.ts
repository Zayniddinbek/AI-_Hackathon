/**
 * Procedural Web Audio API sound generator for Chemistry Lab 3D.
 * Provides zero-latency, realistic, synthesized sound effects for:
 * - Liquid pouring & trickling
 * - Glass clinking
 * - Water simmering / boiling
 * - Mild pop, medium explosion, and violent MEGA explosion
 * - Flame ignition
 */

class LabAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private isMuted = false;

  private init() {
    if (this.ctx) return;
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.75, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    } catch {
      // Web Audio not supported
    }
  }

  private ensureCtx(): AudioContext | null {
    this.init();
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(muted ? 0 : 0.75, this.ctx.currentTime);
    }
  }

  /** Subtle glass clink when moving or selecting glassware */
  public playClink() {
    if (this.isMuted) return;
    const ctx = this.ensureCtx();
    if (!ctx || !this.masterGain) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = "sine";
    osc.frequency.setValueAtTime(1760 + (Math.random() - 0.5) * 200, ctx.currentTime); // A6 chime
    osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.08);

    gain.gain.setValueAtTime(0.12, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.12);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc.stop(ctx.currentTime + 0.13);
  }

  /** Realistic liquid pouring sound stream */
  public playPour(duration = 1.0) {
    if (this.isMuted) return;
    const ctx = this.ensureCtx();
    if (!ctx || !this.masterGain) return;

    const bufferSize = ctx.sampleRate * Math.min(2.5, duration);
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    let lastOut = 0.0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      output[i] = (lastOut + 0.02 * white) / 1.02;
      lastOut = output[i];
      output[i] *= 3.5;
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.setValueAtTime(800, ctx.currentTime);
    filter.frequency.linearRampToValueAtTime(1200, ctx.currentTime + duration * 0.5);
    filter.frequency.linearRampToValueAtTime(700, ctx.currentTime + duration);
    filter.Q.setValueAtTime(3.5, ctx.currentTime);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.01, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.28, ctx.currentTime + 0.1);
    gain.gain.setValueAtTime(0.25, ctx.currentTime + duration - 0.2);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

    whiteNoise.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    whiteNoise.start();
    whiteNoise.stop(ctx.currentTime + duration);
  }

  /** Burner ignition flame sound */
  public playFlame() {
    if (this.isMuted) return;
    const ctx = this.ensureCtx();
    if (!ctx || !this.masterGain) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = "triangle";
    osc.frequency.setValueAtTime(140, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(60, ctx.currentTime + 0.25);

    gain.gain.setValueAtTime(0.25, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc.stop(ctx.currentTime + 0.3);
  }

  /** Boiling bubbling sound */
  public playBubble() {
    if (this.isMuted) return;
    const ctx = this.ensureCtx();
    if (!ctx || !this.masterGain) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = "sine";
    const f0 = 400 + Math.random() * 400;
    osc.frequency.setValueAtTime(f0, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(f0 + 350, ctx.currentTime + 0.06);

    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.07);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc.stop(ctx.currentTime + 0.08);
  }

  /** Chemical reaction explosions with distinct sonic intensity */
  public playExplosion(type: "pop" | "medium" | "mega" = "medium") {
    if (this.isMuted) return;
    const ctx = this.ensureCtx();
    if (!ctx || !this.masterGain) return;

    const now = ctx.currentTime;

    if (type === "pop") {
      // Quick hydrogen pop
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(650, now);
      osc.frequency.exponentialRampToValueAtTime(110, now + 0.12);

      gain.gain.setValueAtTime(0.35, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.16);
      return;
    }

    // Medium or MEGA explosion
    const isMega = type === "mega";
    const dur = isMega ? 1.8 : 1.1;

    // 1. Deep Sub-bass Thud
    const subOsc = ctx.createOscillator();
    const subGain = ctx.createGain();
    subOsc.type = "sine";
    subOsc.frequency.setValueAtTime(isMega ? 160 : 130, now);
    subOsc.frequency.exponentialRampToValueAtTime(25, now + (isMega ? 0.8 : 0.45));

    subGain.gain.setValueAtTime(isMega ? 0.95 : 0.65, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + (isMega ? 0.9 : 0.5));

    subOsc.connect(subGain);
    subGain.connect(this.masterGain);
    subOsc.start(now);
    subOsc.stop(now + (isMega ? 0.95 : 0.55));

    // 2. Violent Noise Blast + Filter Sweep
    const bufferSize = ctx.sampleRate * dur;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * (isMega ? 0.45 : 0.25)));
    }

    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuffer;

    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(isMega ? 3500 : 2200, now);
    filter.frequency.exponentialRampToValueAtTime(120, now + dur);

    const noiseGain = ctx.createGain();
    noiseGain.gain.setValueAtTime(isMega ? 0.9 : 0.6, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + dur);

    noise.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(this.masterGain);

    noise.start(now);
    noise.stop(now + dur);

    // 3. Debris crackle for mega blast
    if (isMega) {
      setTimeout(() => {
        this.playClink();
      }, 180);
      setTimeout(() => {
        this.playClink();
      }, 340);
    }
  }
}

export const labAudio = new LabAudioEngine();
