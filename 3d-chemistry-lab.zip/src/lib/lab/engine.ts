import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { CSS2DRenderer, CSS2DObject } from "three/examples/jsm/renderers/CSS2DRenderer.js";
import { labAudio } from "./audio";
import {
  blendHex,
  blendWeightedHex,
  CLEAR,
  combineChemicalLabels,
  findRxn,
  getChem,
  indicatorColor,
  REACTIONS,
  type Rxn,
} from "./chemistry";

export type VesselType = "beaker" | "flask" | "test_tube" | "cylinder";

export interface VesselInfo {
  id: string;
  type: VesselType;
  label: string;
  chemId: string | null;
  vol: number;
  maxVol: number;
  pH: number;
  temp: number;
  boiling: boolean;
}

export interface LabSnapshot {
  vessels: VesselInfo[];
  selId: string | null;
  burnerOn: boolean;
  /** flame temperature setpoint in °C */
  burnerTemp: number;
  /** number of spills currently on the bench */
  spills: number;
}

interface Puddle {
  mesh: THREE.Mesh;
  mat: THREE.MeshPhysicalMaterial;
  /** ml of liquid in the spill */
  vol: number;
  target: number;
  grown: number;
  temp: number;
  chemId: string | null;
  label: string;
}

interface Vessel {
  id: string;
  type: VesselType;
  chemId: string | null;
  label: string;
  liq: string | null;
  /** agar eritmada indikator bo'lsa, uning id'i (rang pH'ga qarab o'zgaradi) */
  indicator: string | null;
  vol: number;
  pH: number;
  temp: number;
  boil: number;
  group: THREE.Group;
  liquidMesh: THREE.Mesh;
  liquidMat: THREE.MeshPhysicalMaterial;
  surface: THREE.Mesh;
  surfaceMat: THREE.MeshPhysicalMaterial;
  labelEl: HTMLDivElement;
  maxVol: number;
  height: number;
  innerR: number;
  baseY: number;
  wobble: number;
  bubbleT: number;
  moved: boolean;
  /** vertical velocity when free-falling (units/s) */
  vy: number;
  /** highest y reached while being held — decides if the glass survives the drop */
  peakY: number;
  held: boolean;
}

interface Shard {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  rx: number;
  rz: number;
  life: number;
}

type ParticleKind = "bubble" | "smoke" | "flash" | "fireball" | "steam";

interface Particle {
  type: ParticleKind;
  sprite: THREE.Sprite;
  life: number;
  maxLife: number;
  vx: number;
  vy: number;
  vz: number;
  maxR: number;
  baseR: number;
}

export interface LabCallbacks {
  onState: (s: LabSnapshot) => void;
  onLog: (msg: string, kind?: "i" | "s" | "w" | "e") => void;
  onPourRequest: (srcId: string, tgtId: string) => void;
}

const CLEAR = "#8fb6e0";

export class LabEngine {
  private mount: HTMLElement;
  private cb: LabCallbacks;
  private renderer: THREE.WebGLRenderer;
  private labelRenderer: CSS2DRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private controls: OrbitControls;
  private composer: EffectComposer;
  private bloom: UnrealBloomPass;
  private bench = new THREE.Group();
  private vessels: Vessel[] = [];
  private particles: Particle[] = [];
  private glowTex: THREE.Texture;
  private vc = 0;
  private selId: string | null = null;
  private burnerOn = false;
  private burnerGroup = new THREE.Group();
  private flameSprites: THREE.Sprite[] = [];
  private flameLight!: THREE.PointLight;
  private raf = 0;
  private last = performance.now();
  private ro: ResizeObserver;
  private shakeMag = 0;
  private shakeDur = 0;
  private shakeStart = 0;
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private benchPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  private linePlane = new THREE.Plane(new THREE.Vector3(0, 0, 1), 0);
  private activePointers = new Set<number>();
  private dragPointer: number | null = null;
  private dragging: { v: Vessel; offset: THREE.Vector3 } | null = null;
  private downPos = { x: 0, y: 0 };
  private pours: { mesh: THREE.Mesh; t: number; speed: number; done: (() => void) | null }[] = [];
  private baseCam = new THREE.Vector3(0, 6.3, 13.2);
  private readonly BRN = { x: 3.6, z: 0 };
  /** every vessel lives on one straight line across the bench */
  private readonly LINE_Z = 0;
  private readonly GAUZE_Y = 1.85;
  /** drop above this height shatters the glass */
  private readonly BREAK_Y = 2.6;
  /** free space that always stays between two vessels standing on the bench */
  private readonly GAP = 1.05;
  /** vessels currently inside a pour choreography (gravity/auto-layout paused) */
  private busy = new Set<string>();
  private shards: Shard[] = [];
  /** burner flame temperature setpoint in °C */
  private burnerTemp = 500;
  private puddles: Puddle[] = [];

  constructor(mount: HTMLElement, cb: LabCallbacks) {
    this.mount = mount;
    this.cb = cb;

    const W = () => mount.clientWidth || 1;
    const H = () => mount.clientHeight || 1;

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: "high-performance",
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.85;
    this.renderer.setSize(W(), H());
    this.renderer.domElement.style.touchAction = "none";
    mount.appendChild(this.renderer.domElement);

    this.labelRenderer = new CSS2DRenderer();
    this.labelRenderer.setSize(W(), H());
    const ldom = this.labelRenderer.domElement;
    ldom.style.position = "absolute";
    ldom.style.inset = "0";
    ldom.style.pointerEvents = "none";
    mount.appendChild(ldom);

    this.scene.background = new THREE.Color(0x05070d);
    this.scene.fog = new THREE.FogExp2(0x05070d, 0.026);

    // real reflections/refractions for glass
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.03).texture;

    this.camera = new THREE.PerspectiveCamera(42, W() / H(), 0.1, 200);
    this.camera.position.copy(this.baseCam);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.target.set(0, 1.5, 0);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.minDistance = 5;
    this.controls.maxDistance = 22;
    this.controls.maxPolarAngle = Math.PI * 0.49;
    this.controls.minPolarAngle = Math.PI * 0.12;
    this.controls.enablePan = false;
    this.controls.enableZoom = true;
    this.controls.rotateSpeed = 0.8;
    this.controls.zoomSpeed = 0.9;
    this.controls.touches = { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_ROTATE };
    this.controls.update();

    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.bloom = new UnrealBloomPass(new THREE.Vector2(W(), H()), 0.2, 0.4, 1.15);
    this.composer.addPass(this.bloom);

    this.scene.add(new THREE.HemisphereLight(0x405580, 0x080d18, 0.65));
    const key = new THREE.DirectionalLight(0xdde8ff, 0.92);
    key.position.set(-6, 12, 6);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    key.shadow.camera.left = -12;
    key.shadow.camera.right = 12;
    key.shadow.camera.top = 12;
    key.shadow.camera.bottom = -12;
    key.shadow.bias = -0.0015;
    this.scene.add(key);
    const rim = new THREE.DirectionalLight(0x5a9fe8, 0.35);
    rim.position.set(8, 5, -8);
    this.scene.add(rim);

    this.scene.add(this.bench);
    this.buildRoom();
    this.glowTex = this.makeGlowTexture();
    this.buildBurner();

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(mount);

    const dom = this.renderer.domElement;
    dom.addEventListener("pointerdown", this.onPointerDown);
    dom.addEventListener("pointermove", this.onPointerMove);
    window.addEventListener("pointerup", this.onPointerUp);

    this.raf = requestAnimationFrame(this.animate);
    this.emit();
  }

  // ---------------- scene build ----------------
  private buildRoom() {
    const topMat = new THREE.MeshStandardMaterial({
      color: 0x161b26,
      roughness: 0.68,
      metalness: 0.12,
    });
    const bench = new THREE.Mesh(new THREE.BoxGeometry(20, 0.5, 5.2), topMat);
    bench.position.y = -0.25;
    bench.receiveShadow = true;
    this.bench.add(bench);

    const legMat = new THREE.MeshStandardMaterial({
      color: 0x0d1018,
      roughness: 0.5,
      metalness: 0.6,
    });
    for (const lx of [-9.3, 9.3]) {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.4, 4.2, 4.6), legMat);
      leg.position.set(lx, -2.35, 0);
      leg.castShadow = true;
      leg.receiveShadow = true;
      this.bench.add(leg);
    }
    const strip = new THREE.Mesh(
      new THREE.BoxGeometry(19.6, 0.05, 0.08),
      new THREE.MeshStandardMaterial({
        color: 0x2a3550,
        emissive: 0x2f7bd8,
        emissiveIntensity: 1.6,
        roughness: 0.4,
      }),
    );
    strip.position.set(0, 0.005, 2.58);
    this.bench.add(strip);

    const wall = new THREE.Mesh(
      new THREE.PlaneGeometry(46, 18),
      new THREE.MeshStandardMaterial({ color: 0x0a0d16, roughness: 0.92 }),
    );
    wall.position.set(0, 5.5, -6);
    wall.receiveShadow = true;
    this.scene.add(wall);

    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(70, 44),
      new THREE.MeshStandardMaterial({ color: 0x070a12, roughness: 1 }),
    );
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -4.5;
    floor.receiveShadow = true;
    this.scene.add(floor);

    // chalkboard with reaction equations instead of decorative bottles
    this.buildBoard();
  }

  private boardCtx: CanvasRenderingContext2D | null = null;
  private boardTex: THREE.CanvasTexture | null = null;
  private boardEqs: string[] = [];

  private buildBoard() {
    const frame = new THREE.Mesh(
      new THREE.BoxGeometry(9.4, 4.2, 0.2),
      new THREE.MeshStandardMaterial({ color: 0x3d2817, roughness: 0.75, metalness: 0.08 }),
    );
    frame.position.set(0, 3.45, -5.75);
    this.scene.add(frame);

    const c = document.createElement("canvas");
    c.width = 2048;
    c.height = 1024;
    this.boardCtx = c.getContext("2d");
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    this.boardTex = tex;
    const board = new THREE.Mesh(
      new THREE.PlaneGeometry(8.8, 3.7),
      new THREE.MeshStandardMaterial({ map: tex, roughness: 0.92, metalness: 0 }),
    );
    board.position.set(0, 3.45, -5.63);
    this.scene.add(board);
    this.drawBoard();
  }

  /** Chalk-style board: clear, high-contrast, large essential reactions and formulas. */
  private drawBoard() {
    const ctx = this.boardCtx;
    if (!ctx) return;
    const W = 2048;
    const H = 1024;
    // Dark chalkboard slate background
    ctx.fillStyle = "#101d18";
    ctx.fillRect(0, 0, W, H);

    // Chalk dust texture
    for (let i = 0; i < 1000; i++) {
      ctx.fillStyle = `rgba(220,240,230,${Math.random() * 0.03})`;
      ctx.fillRect(
        Math.random() * W,
        Math.random() * H,
        2 + Math.random() * 28,
        1 + Math.random() * 2,
      );
    }

    // Outer chalk border
    ctx.strokeStyle = "rgba(220,240,230,0.3)";
    ctx.lineWidth = 3;
    ctx.strokeRect(24, 24, W - 48, H - 48);

    // Title Header
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#bbf7d0";
    ctx.font = "bold 46px 'Share Tech Mono', monospace";
    ctx.fillText("🧪 ASOSIY KIMYOVIY REAKSIYALAR VA FORMULALAR 🧪", 56, 78);

    ctx.strokeStyle = "rgba(230,245,235,0.45)";
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(48, 100);
    ctx.lineTo(W - 48, 100);
    ctx.stroke();

    const recent = this.boardEqs;

    // Two spacious, large-text columns
    const colW = (W - 140) / 2;
    const leftX = 56;
    const rightX = 56 + colW + 36;

    // Vertical column divider
    ctx.strokeStyle = "rgba(230,245,235,0.25)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(leftX + colW + 18, 116);
    ctx.lineTo(leftX + colW + 18, H - 85);
    ctx.stroke();

    // Section 1 (Left top): Neytrallanish
    let yLeft = 150;
    ctx.fillStyle = "#6ee7b7";
    ctx.font = "bold 34px 'Share Tech Mono', monospace";
    ctx.fillText("① NEYTRALLANISH (KISLOTA + ISHQOR)", leftX, yLeft);
    yLeft += 46;

    const sec1 = [
      "HCl + NaOH → NaCl + H₂O",
      "H₂SO₄ + 2NaOH → Na₂SO₄ + 2H₂O",
      "HCl + KOH → KCl + H₂O",
      "NH₃ + HCl → NH₄Cl (Oq tutun)",
    ];

    sec1.forEach((eq) => {
      const isRecent = recent.includes(eq);
      ctx.fillStyle = isRecent ? "#fde047" : "#ffffff";
      ctx.font = isRecent
        ? "bold 36px 'Share Tech Mono', monospace"
        : "34px 'Share Tech Mono', monospace";
      ctx.fillText(`${isRecent ? "★" : "·"} ${eq}`, leftX + 16, yLeft);
      yLeft += 44;
    });

    // Section 2 (Left bottom): Metallar
    yLeft += 24;
    ctx.fillStyle = "#fdba74";
    ctx.font = "bold 34px 'Share Tech Mono', monospace";
    ctx.fillText("② METALLARNING FAOL REAKSIYALARI", leftX, yLeft);
    yLeft += 46;

    const sec2 = [
      "2Na + 2H₂O → 2NaOH + H₂↑ (Portlash)",
      "2K + 2H₂O → 2KOH + H₂↑ (Ekzotermik)",
      "2Na + 2HCl → 2NaCl + H₂↑",
    ];

    sec2.forEach((eq) => {
      const isRecent = recent.includes(eq);
      ctx.fillStyle = isRecent ? "#fde047" : "#ffffff";
      ctx.font = isRecent
        ? "bold 36px 'Share Tech Mono', monospace"
        : "34px 'Share Tech Mono', monospace";
      ctx.fillText(`${isRecent ? "★" : "·"} ${eq}`, leftX + 16, yLeft);
      yLeft += 44;
    });

    // Section 3 (Right top): Cho'kma va Oksidlanish
    let yRight = 150;
    ctx.fillStyle = "#93c5fd";
    ctx.font = "bold 34px 'Share Tech Mono', monospace";
    ctx.fillText("③ CHO'KMA VA OKSIDLANISH", rightX, yRight);
    yRight += 46;

    const sec3 = [
      "CuSO₄ + 2NaOH → Cu(OH)₂↓ + Na₂SO₄",
      "FeCl₃ + 3NaOH → Fe(OH)₃↓ + 3NaCl",
      "2H₂O₂ → 2H₂O + O₂↑ (Katalizator: FeCl₃)",
    ];

    sec3.forEach((eq) => {
      const isRecent = recent.includes(eq);
      ctx.fillStyle = isRecent ? "#fde047" : "#ffffff";
      ctx.font = isRecent
        ? "bold 36px 'Share Tech Mono', monospace"
        : "34px 'Share Tech Mono', monospace";
      ctx.fillText(`${isRecent ? "★" : "·"} ${eq}`, rightX + 16, yRight);
      yRight += 44;
    });

    // Section 4 (Right bottom): Indikatorlar
    yRight += 24;
    ctx.fillStyle = "#f472b6";
    ctx.font = "bold 34px 'Share Tech Mono', monospace";
    ctx.fillText("④ INDIKATORLAR VA SHKALA", rightX, yRight);
    yRight += 46;

    const sec4 = [
      "Lakmus:  Kislotada [QIZIL] | Ishqorda [KO'K]",
      "Fenolftalein:  Neytral [RANGSIZ] | Ishqorda [PUSHTI]",
      "Gorelka:  100°C+ da qaynash va bug' ajraladi",
    ];

    sec4.forEach((eq) => {
      ctx.fillStyle = "#e2e8f0";
      ctx.font = "32px 'Share Tech Mono', monospace";
      ctx.fillText(`· ${eq}`, rightX + 16, yRight);
      yRight += 44;
    });

    // Bottom Footer bar
    ctx.strokeStyle = "rgba(230,245,235,0.3)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(48, H - 75);
    ctx.lineTo(W - 48, H - 75);
    ctx.stroke();

    ctx.fillStyle = recent.length ? "#fde047" : "rgba(230,245,235,0.75)";
    ctx.font = "bold 28px 'Share Tech Mono', monospace";
    ctx.fillText(
      recent.length
        ? `★ So'nggi amalga oshgan reaksiya: ${recent[0]}`
        : "★ Reaksiyalar o'tkazilganda doskada tilla rang bilan ko'rsatiladi",
      56,
      H - 34,
    );

    if (this.boardTex) this.boardTex.needsUpdate = true;
  }

  /** Puts the equation of a reaction that just happened on top of the board. */
  private logEqOnBoard(eq: string) {
    this.boardEqs = [eq, ...this.boardEqs.filter((x) => x !== eq)].slice(0, 10);
    this.drawBoard();
  }

  /** Board back to its pristine state (used by bench cleanup). */
  private clearBoard() {
    this.boardEqs = [];
    this.drawBoard();
  }

  private makeGlowTexture() {
    const c = document.createElement("canvas");
    c.width = 128;
    c.height = 128;
    const ctx = c.getContext("2d")!;
    const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
    g.addColorStop(0, "rgba(255,255,255,1)");
    g.addColorStop(0.35, "rgba(255,255,255,0.55)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 128, 128);
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  private buildBurner() {
    this.burnerGroup.position.set(this.BRN.x, 0, this.BRN.z);
    this.bench.add(this.burnerGroup);
    const metal = new THREE.MeshStandardMaterial({
      color: 0x20222c,
      roughness: 0.32,
      metalness: 0.85,
    });
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.0, 0.18, 28), metal);
    base.position.y = 0.09;
    base.castShadow = true;
    base.receiveShadow = true;
    this.burnerGroup.add(base);
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 1.1, 16), metal);
    stem.position.y = 0.73;
    stem.castShadow = true;
    this.burnerGroup.add(stem);
    const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.1, 16), metal);
    collar.position.y = 1.18;
    this.burnerGroup.add(collar);
    // tripod legs holding a gauze plate above the flame
    for (let i = 0; i < 3; i++) {
      const a = (i / 3) * Math.PI * 2;
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.8, 8), metal);
      leg.position.set(Math.cos(a) * 0.8, 0.9, Math.sin(a) * 0.8);
      leg.castShadow = true;
      this.burnerGroup.add(leg);
    }
    const gauze = new THREE.Mesh(
      new THREE.CylinderGeometry(0.95, 0.95, 0.05, 24),
      new THREE.MeshStandardMaterial({ color: 0x3a3f4c, roughness: 0.85, metalness: 0.4 }),
    );
    gauze.position.y = 1.8;
    gauze.castShadow = true;
    gauze.receiveShadow = true;
    this.burnerGroup.add(gauze);

    // Responsive click hitbox covering entire burner volume
    const burnerHit = new THREE.Mesh(
      new THREE.CylinderGeometry(1.05, 1.05, 2.1, 16),
      new THREE.MeshBasicMaterial({ visible: false }),
    );
    burnerHit.position.y = 1.05;
    this.burnerGroup.add(burnerHit);

    this.flameLight = new THREE.PointLight(0xff8a2a, 0, 8, 2);
    this.flameLight.position.set(0, 1.5, 0);
    this.burnerGroup.add(this.flameLight);

    const flameGroup = new THREE.Group();
    flameGroup.position.y = 1.25;
    this.burnerGroup.add(flameGroup);
    for (let i = 0; i < 6; i++) {
      const mat = new THREE.SpriteMaterial({
        map: this.glowTex,
        color: i < 2 ? 0x6fd0ff : 0xff9a2a,
        transparent: true,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        opacity: 0,
      });
      const spr = new THREE.Sprite(mat);
      spr.scale.set(0.4, 0.7, 1);
      flameGroup.add(spr);
      this.flameSprites.push(spr);
    }
  }

  private glassMaterial() {
    // Highly realistic, transparent laboratory borosilicate glass
    return new THREE.MeshPhysicalMaterial({
      color: 0xe6f0fc,
      metalness: 0.0,
      roughness: 0.06,
      transparent: true,
      opacity: 0.28,
      side: THREE.DoubleSide,
      clearcoat: 1,
      clearcoatRoughness: 0.08,
      envMapIntensity: 0.65,
      depthWrite: false,
    });
  }

  private liquidMaterial(color: string) {
    return new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(color),
      roughness: 0.08,
      metalness: 0.0,
      transmission: 0.76,
      thickness: 0.65,
      ior: 1.333,
      envMapIntensity: 0.6,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
  }

  private gradMarks(g: THREE.Group, r: number, height: number, count: number) {
    const mat = new THREE.MeshBasicMaterial({ color: 0xb9cfea, transparent: true, opacity: 0.5 });
    for (let i = 1; i <= count; i++) {
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(r + 0.004, 0.005, 6, 24, Math.PI * 0.5),
        mat,
      );
      ring.rotation.x = Math.PI / 2;
      ring.position.y = (height / (count + 1)) * i;
      g.add(ring);
    }
  }

  private getInnerRadiusAt(type: VesselType, y: number): number {
    if (type === "beaker") {
      const t = Math.max(0, Math.min(1, (y - 0.03) / 1.67));
      return 0.465 + t * 0.075;
    } else if (type === "flask") {
      if (y <= 0.06) return 0.52;
      if (y <= 0.34) {
        const t = (y - 0.06) / (0.34 - 0.06);
        return 0.52 + t * 0.065;
      }
      if (y <= 0.6) {
        const t = (y - 0.34) / (0.6 - 0.34);
        return 0.585 - t * 0.02;
      }
      if (y <= 1.25) {
        const t = (y - 0.6) / (1.25 - 0.6);
        return 0.565 - t * 0.43;
      }
      return 0.105;
    } else if (type === "test_tube") {
      if (y <= 0.28) {
        const dy = 0.28 - y;
        return Math.sqrt(Math.max(0.001, 0.225 * 0.225 - dy * dy));
      }
      return 0.225;
    } else {
      return 0.205;
    }
  }

  private buildLiquidGeometry(
    type: VesselType,
    baseY: number,
    fillH: number,
  ): THREE.BufferGeometry {
    const topY = baseY + fillH;
    const steps = 18;
    const pts: THREE.Vector2[] = [];
    pts.push(new THREE.Vector2(0, baseY));
    for (let i = 0; i <= steps; i++) {
      const curY = baseY + (fillH * i) / steps;
      const r = this.getInnerRadiusAt(type, curY);
      pts.push(new THREE.Vector2(r, curY));
    }
    pts.push(new THREE.Vector2(0, topY));
    return new THREE.LatheGeometry(pts, 36);
  }

  private buildVesselMesh(type: VesselType) {
    const g = new THREE.Group();
    let height: number, innerR: number, baseY: number, maxVol: number;

    if (type === "beaker") {
      height = 1.7;
      const rTop = 0.58,
        rBot = 0.5;
      innerR = rBot * 0.92;
      baseY = 0.03;
      maxVol = 300;
      const shell = new THREE.Mesh(
        new THREE.CylinderGeometry(rTop, rBot, height, 40, 1, true),
        this.glassMaterial(),
      );
      shell.position.y = height / 2;
      shell.castShadow = true;
      const bottom = new THREE.Mesh(
        new THREE.CylinderGeometry(rBot, rBot, 0.05, 40),
        this.glassMaterial(),
      );
      bottom.position.y = 0.025;
      const rim = new THREE.Mesh(
        new THREE.TorusGeometry(rTop, 0.016, 10, 40),
        new THREE.MeshPhysicalMaterial({
          color: 0xe4edff,
          roughness: 0.15,
          transparent: true,
          opacity: 0.55,
          clearcoat: 1,
        }),
      );
      rim.rotation.x = Math.PI / 2;
      rim.position.y = height;
      g.add(shell, bottom, rim);
      this.gradMarks(g, rTop * 0.99, height, 4);
    } else if (type === "flask") {
      height = 1.68;
      innerR = 0.5;
      baseY = 0.06;
      maxVol = 250;
      const pts = [
        new THREE.Vector2(0, 0),
        new THREE.Vector2(0.56, 0.06),
        new THREE.Vector2(0.62, 0.34),
        new THREE.Vector2(0.6, 0.6),
        new THREE.Vector2(0.17, 1.25),
        new THREE.Vector2(0.135, 1.58),
        new THREE.Vector2(0.135, height),
      ];
      const shell = new THREE.Mesh(new THREE.LatheGeometry(pts, 40), this.glassMaterial());
      shell.castShadow = true;
      const rim = new THREE.Mesh(
        new THREE.TorusGeometry(0.135, 0.013, 8, 24),
        new THREE.MeshPhysicalMaterial({
          color: 0xe4edff,
          roughness: 0.15,
          transparent: true,
          opacity: 0.55,
          clearcoat: 1,
        }),
      );
      rim.rotation.x = Math.PI / 2;
      rim.position.y = height;
      g.add(shell, rim);
    } else if (type === "test_tube") {
      height = 1.55;
      const r = 0.26;
      innerR = r * 0.86;
      baseY = 0.03;
      maxVol = 120;
      const pts: THREE.Vector2[] = [];
      for (let i = 0; i <= 10; i++) {
        const t = (i / 10) * Math.PI * 0.5;
        pts.push(new THREE.Vector2(Math.sin(t) * r, r - Math.cos(t) * r));
      }
      pts.push(new THREE.Vector2(r, height));
      const shell = new THREE.Mesh(new THREE.LatheGeometry(pts, 32), this.glassMaterial());
      shell.castShadow = true;
      g.add(shell);
    } else {
      height = 1.9;
      const r = 0.24;
      innerR = r * 0.88;
      baseY = 0.05;
      maxVol = 190;
      const shell = new THREE.Mesh(
        new THREE.CylinderGeometry(r, r, height, 32, 1, true),
        this.glassMaterial(),
      );
      shell.position.y = height / 2;
      shell.castShadow = true;
      const foot = new THREE.Mesh(
        new THREE.CylinderGeometry(0.42, 0.46, 0.09, 32),
        this.glassMaterial(),
      );
      foot.position.y = 0.045;
      g.add(shell, foot);
      this.gradMarks(g, r, height, 6);
    }

    const liquidMat = this.liquidMaterial(CLEAR);
    const initialLiqGeo = this.buildLiquidGeometry(type, baseY, 0.01);
    const liquid = new THREE.Mesh(initialLiqGeo, liquidMat);
    liquid.visible = false;
    g.add(liquid);

    const surfaceMat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(CLEAR),
      roughness: 0.04,
      metalness: 0.0,
      transmission: 0.74,
      thickness: 0.4,
      ior: 1.333,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const surface = new THREE.Mesh(new THREE.CircleGeometry(innerR, 36), surfaceMat);
    surface.rotation.x = -Math.PI / 2;
    surface.visible = false;
    g.add(surface);

    // Responsive touch & click hitbox for tablets and mobile
    const hitR = Math.max(0.48, innerR + 0.16);
    const touchHitbox = new THREE.Mesh(
      new THREE.CylinderGeometry(hitR, hitR, height + 0.2, 16),
      new THREE.MeshBasicMaterial({ visible: false }),
    );
    touchHitbox.position.y = height / 2;
    g.add(touchHitbox);

    return { group: g, liquid, liquidMat, surface, surfaceMat, height, innerR, baseY, maxVol };
  }

  // ---------------- public API ----------------
  addVessel(type: VesselType, chemId: string | null, fallbackLabel: string) {
    const chem = getChem(chemId);
    const built = this.buildVesselMesh(type);
    const group = new THREE.Group();
    group.add(built.group);
    const n = this.vessels.length;
    group.position.set(0, 0, this.LINE_Z);
    this.bench.add(group);

    const labelEl = document.createElement("div");
    labelEl.className = "v-label";
    const labelObj = new CSS2DObject(labelEl);
    labelObj.position.set(0, built.height + 0.4, 0);
    group.add(labelObj);

    const v: Vessel = {
      id: "v" + ++this.vc,
      type,
      chemId,
      label: chem ? chem.f : fallbackLabel,
      liq: chem ? chem.color : null,
      indicator: chem && chem.type === "indicator" ? chem.id : null,
      vol: chem ? 100 : 0,
      pH: chem ? chem.pH : 7,
      temp: 22,
      boil: chem ? chem.boil : 100,
      group,
      liquidMesh: built.liquid,
      liquidMat: built.liquidMat,
      surface: built.surface,
      surfaceMat: built.surfaceMat,
      labelEl,
      maxVol: built.maxVol,
      height: built.height,
      innerR: built.innerR,
      baseY: built.baseY,
      wobble: 0,
      bubbleT: 0,
      moved: false,
      vy: 0,
      peakY: 0,
      held: false,
    };
    this.vessels.push(v);
    this.selId = v.id;
    this.relayout();
    this.refresh(v);
    labAudio.playClink();
    this.cb.onLog(`${chem ? `${chem.f} (${chem.n})` : fallbackLabel} stolga qo'yildi`, "i");
    this.emit();
  }

  /** Lines every untouched vessel up on the single bench line (depth ignored). */
  private relayout() {
    const n = this.vessels.length;
    const step = Math.min(2.4, 15 / Math.max(n, 1));
    this.vessels.forEach((v, i) => {
      v.group.position.z = this.LINE_Z;
      if (v.moved) return;
      v.group.position.x = (i - (n - 1) / 2) * step - 1.2;
    });
    this.separate();
  }

  /** Half-width of a vessel's footprint on the bench. */
  private footprint(v: Vessel) {
    if (v.type === "flask") return 0.65;
    if (v.type === "beaker") return 0.6;
    if (v.type === "cylinder") return 0.48;
    return 0.32; // test_tube
  }

  /** Minimum centre distance so two glasses never touch or penetrate each other. */
  private minGap(a: Vessel, b: Vessel) {
    return this.footprint(a) + this.footprint(b) + 0.12;
  }

  /**
   * Pushes resting vessels apart along the bench line so no two ever end up
   * on top of each other — a real, clear gap always stays between neighbours.
   */
  private separate() {
    for (let it = 0; it < 24; it++) {
      let moved = false;
      const list = [...this.vessels].sort((a, b) => a.group.position.x - b.group.position.x);
      for (let i = 0; i < list.length - 1; i++) {
        const a = list[i]!;
        const b = list[i + 1]!;
        const min = this.minGap(a, b);
        const d = b.group.position.x - a.group.position.x;
        if (d >= min - 0.001) continue;
        const push = (min - d) / 2 + 0.04;
        const aFree = !a.held && !this.busy.has(a.id);
        const bFree = !b.held && !this.busy.has(b.id);
        if (aFree)
          a.group.position.x = THREE.MathUtils.clamp(
            a.group.position.x - (bFree ? push : push * 2),
            -9.2,
            9.2,
          );
        if (bFree)
          b.group.position.x = THREE.MathUtils.clamp(
            b.group.position.x + (aFree ? push : push * 2),
            -9.2,
            9.2,
          );
        if (aFree || bFree) {
          a.moved = true;
          b.moved = true;
          moved = true;
        }
      }
      if (!moved) break;
    }
  }

  /** Nearest free x on the bench line where `v` won't collide or overlap with anyone. */
  private freeSpot(v: Vessel, wish: number, excludeId?: string) {
    const others = this.vessels.filter((o) => o.id !== v.id && o.id !== excludeId);
    const ok = (x: number) =>
      others.every((o) => Math.abs(o.group.position.x - x) >= this.minGap(v, o) - 0.01);
    if (ok(wish)) return THREE.MathUtils.clamp(wish, -8.8, 8.8);
    for (let d = 0.15; d <= 16; d += 0.15) {
      for (const x of [wish - d, wish + d]) {
        if (x >= -8.8 && x <= 8.8 && ok(x)) return x;
      }
    }
    return THREE.MathUtils.clamp(wish, -8.8, 8.8);
  }

  /** Cancel pour request and smoothly return vessel to safe separated resting spot on bench */
  cancelPour(srcId: string) {
    const src = this.vessels.find((v) => v.id === srcId);
    if (!src) return;
    this.busy.add(src.id);
    src.held = true;
    src.vy = 0;
    const safeX = this.freeSpot(src, src.group.position.x);
    const overBurner = Math.abs(safeX - this.BRN.x) < 1.05;
    const restY = overBurner ? this.GAUZE_Y : 0;
    const fx = src.group.position.x;
    const fy = src.group.position.y;
    const frot = src.group.rotation.z;
    this.tween(
      0.35,
      (p) => {
        src.group.position.x = fx + (safeX - fx) * p;
        src.group.position.y = fy + (restY - fy) * p;
        src.group.rotation.z = frot * (1 - p);
        src.group.position.z = this.LINE_Z;
      },
      () => {
        src.group.position.set(safeX, restY, this.LINE_Z);
        src.group.rotation.z = 0;
        src.vy = 0;
        src.peakY = restY;
        src.held = false;
        src.moved = true;
        this.busy.delete(src.id);
        this.separate();
        this.emit();
      },
    );
  }

  /** Simple eased tween driven by the same per-frame stream loop. */
  private tween(dur: number, onUpdate: (p: number) => void, onDone?: () => void) {
    let t = 0;
    this.streams.push((dt) => {
      t += dt;
      const p = Math.min(1, t / dur);
      onUpdate(p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2);
      if (p >= 1) {
        onDone?.();
        return false;
      }
      return true;
    });
  }

  select(id: string | null) {
    this.selId = id;
    this.emit();
  }

  removeVessel(id: string) {
    const v = this.vessels.find((x) => x.id === id);
    if (!v) return;
    v.group.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
      const mat = m.material as THREE.Material | THREE.Material[] | undefined;
      if (mat) (Array.isArray(mat) ? mat : [mat]).forEach((x) => x.dispose());
      if (o instanceof CSS2DObject) o.element.remove();
    });
    this.bench.remove(v.group);
    v.labelEl.remove();
    this.vessels = this.vessels.filter((x) => x.id !== id);
    if (this.selId === id) this.selId = this.vessels[0]?.id ?? null;
    this.relayout();
    this.emit();
  }

  reset() {
    this.streams = [];
    this.busy.clear();
    [...this.vessels].forEach((v) => this.removeVessel(v.id));
    const spills = this.puddles.length;
    this.clearSpills();
    this.clearShards();
    this.clearBoard();
    this.cb.onLog(
      spills
        ? `Stol tozalandi — ${spills} to'kilgan dog' artildi, doska ham o'chirildi`
        : "Stol tozalandi — doska o'chirildi",
      "w",
    );
    this.emit();
  }

  /** Wipes every spilled puddle off the bench. */
  clearSpills() {
    for (const p of this.puddles) {
      this.scene.remove(p.mesh);
      p.mesh.geometry.dispose();
      p.mat.dispose();
    }
    this.puddles = [];
  }

  private clearShards() {
    for (const s of this.shards) {
      this.scene.remove(s.mesh);
      s.mesh.geometry.dispose();
    }
    this.shards = [];
  }

  /** Flame temperature setpoint — vessels approach this while heated. */
  setBurnerTemp(t: number) {
    this.burnerTemp = THREE.MathUtils.clamp(Math.round(t), 60, 1200);
    this.emit();
  }

  toggleBurner() {
    this.burnerOn = !this.burnerOn;
    if (this.burnerOn) {
      labAudio.playFlame();
    }
    this.cb.onLog(
      this.burnerOn ? `🔥 Gorelka yondirildi — ${this.burnerTemp}°C` : "Gorelka o'chirildi",
      this.burnerOn ? "w" : "i",
    );
    this.emit();
  }

  pour(srcId: string, tgtId: string, amount: number) {
    const src = this.vessels.find((v) => v.id === srcId);
    const tgt = this.vessels.find((v) => v.id === tgtId);
    if (!src || !tgt || !src.liq || src.vol <= 0.5) return;
    const wanted = Math.min(amount, src.vol);
    const amt = Math.min(wanted, tgt.maxVol - tgt.vol);
    const overflow = wanted - amt;
    if (amt <= 0) {
      this.cb.onLog(`${tgt.label} to'lgan — joy yo'q, suyuqlik stolga to'kiladi`, "w");
      src.vol = Math.max(0, src.vol - wanted);
      if (src.vol < 0.5) {
        src.vol = 0;
        src.liq = null;
      }
      this.addSpill(
        tgt.group.position.x + 0.7,
        tgt.group.position.z,
        src.liq ?? CLEAR,
        wanted,
        src.temp,
        src.chemId,
        src.label,
      );
      this.refresh(src);
      this.emit();
      return;
    }
    const color = src.liq;
    if (overflow > 0.5) {
      src.vol = Math.max(0, src.vol - overflow);
      this.addSpill(
        tgt.group.position.x + 0.7,
        tgt.group.position.z,
        color,
        overflow,
        src.temp,
        src.chemId,
        src.label,
      );
    }

    const total = amt;
    const tiltDir = Math.sign(tgt.group.position.x - src.group.position.x) || 1;
    const startRot = src.group.rotation.z;

    // ---- pour choreography: lift beside the target rim, tilt, pour, stand back with guaranteed gap ----
    const tgtRimY = tgt.group.position.y + tgt.height;
    const stand = this.footprint(tgt) + this.footprint(src) * 0.45;
    const poseX = THREE.MathUtils.clamp(tgt.group.position.x - tiltDir * stand, -9, 9);
    const poseY = tgtRimY + 0.65;
    const fromX = src.group.position.x;
    const fromY = src.group.position.y;
    this.busy.add(src.id);
    src.held = true; // choreography drives the transform, gravity waits
    src.vy = 0;
    let poured = 0;

    const stepBack = () => {
      // Find a safe spot away from target with full clearance on the bench
      const safeOffset = -tiltDir * (this.minGap(src, tgt) + 0.3);
      const desiredX = tgt.group.position.x + safeOffset;
      const restX = this.freeSpot(src, desiredX, tgt.id);
      const overBurner = Math.abs(restX - this.BRN.x) < 1.05;
      const restY = overBurner ? this.GAUZE_Y : 0;
      const fx = src.group.position.x;
      const fy = src.group.position.y;
      const rot = src.group.rotation.z;
      this.tween(
        0.48,
        (p) => {
          src.group.rotation.z = rot * (1 - p);
          src.group.position.x = fx + (restX - fx) * p;
          src.group.position.y = fy + (restY - fy) * p;
          src.group.position.z = this.LINE_Z;
        },
        () => {
          src.group.rotation.z = 0;
          src.group.position.set(restX, restY, this.LINE_Z);
          src.peakY = restY;
          src.vy = 0;
          src.held = false;
          src.moved = true;
          this.busy.delete(src.id);
          this.separate();
          this.emit();
        },
      );
    };

    const startPouring = () =>
      this.startStream(
        src,
        tgt,
        color,
        (dt) => {
          const rate = total / 0.85;
          const d = Math.min(total - poured, rate * dt);
          poured += d;
          src.vol = Math.max(0, src.vol - d);
          if (src.vol < 0.5) {
            src.vol = 0;
            src.liq = null;
            src.indicator = null;
          }
          tgt.wobble = 1;
          this.refresh(src);
        },
        () => {
          const rxn = findRxn(src.chemId, tgt.chemId, src.label, tgt.label);
          if (rxn) {
            this.applyRxn(tgt, rxn, total);
          } else {
            if (!tgt.liq) {
              tgt.liq = color;
              tgt.chemId = src.chemId;
              tgt.label = src.label;
              tgt.pH = src.pH;
              tgt.boil = src.boil;
              tgt.indicator = src.indicator;
              tgt.vol = Math.min(tgt.maxVol, tgt.vol + total);
            } else {
              const w = total / Math.max(1, tgt.vol + total);
              tgt.pH = tgt.pH * (1 - w) + src.pH * w;
              tgt.temp = tgt.temp * (1 - w) + src.temp * w;
              tgt.liq = blendWeightedHex(tgt.liq, color, w);
              tgt.indicator = tgt.indicator ?? src.indicator;
              tgt.label = combineChemicalLabels(tgt.label, src.label);
              tgt.chemId = null;
              tgt.vol = Math.min(tgt.maxVol, tgt.vol + total);
            }
            this.applyIndicator(tgt);
            this.cb.onLog(`${total.toFixed(0)}ml quyildi — aralashma hosil bo'ldi`, "i");
            this.refresh(tgt);
          }
          this.emit();
          stepBack();
        },
      );

    // 1) lift and position beside the target, 2) tilt spout over target mouth, 3) pour stream
    const maxTilt = -tiltDir * 0.74;
    this.tween(
      0.38,
      (p) => {
        src.group.position.x = fromX + (poseX - fromX) * p;
        src.group.position.y = fromY + (poseY - fromY) * p + Math.sin(Math.PI * p) * 0.2;
        src.group.position.z = this.LINE_Z;
        src.group.rotation.z = startRot + (maxTilt * 0.3 - startRot) * p;
      },
      () =>
        this.tween(
          0.24,
          (p) => {
            src.group.rotation.z = maxTilt * 0.3 + maxTilt * 0.7 * p;
          },
          startPouring,
        ),
    );
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    const dom = this.renderer.domElement;
    dom.removeEventListener("pointerdown", this.onPointerDown);
    dom.removeEventListener("pointermove", this.onPointerMove);
    window.removeEventListener("pointerup", this.onPointerUp);
    [...this.vessels].forEach((v) => this.removeVessel(v.id));
    this.clearSpills();
    this.clearShards();

    this.controls.dispose();
    this.composer.dispose();
    this.renderer.dispose();
    dom.remove();
    this.labelRenderer.domElement.remove();
  }

  // ---------------- internals ----------------
  private emit() {
    this.vessels.forEach((v) => this.refreshLabel(v));
    this.cb.onState({
      selId: this.selId,
      burnerOn: this.burnerOn,
      burnerTemp: this.burnerTemp,
      spills: this.puddles.length,

      vessels: this.vessels.map((v) => ({
        id: v.id,
        type: v.type,
        label: v.label,
        chemId: v.chemId,
        vol: v.vol,
        maxVol: v.maxVol,
        pH: v.pH,
        temp: v.temp,
        boiling: v.vol > 0.5 && v.temp >= v.boil,
      })),
    });
  }

  private refreshLabel(v: Vessel) {
    v.labelEl.innerHTML =
      `<div class="vlabel-f">${v.label}</div>` +
      (v.vol > 0.5
        ? `<div class="vlabel-v">${v.vol.toFixed(0)}ml · pH ${v.pH.toFixed(1)}${v.temp > 26 ? ` · ${v.temp.toFixed(0)}°C` : ""}</div>`
        : "");
    v.labelEl.classList.toggle("sel", v.id === this.selId);
  }

  private refresh(v: Vessel) {
    const frac = Math.max(0, Math.min(1, v.vol / v.maxVol));
    const fillH = Math.max(0.001, frac * (v.height - 0.12));

    if (v.vol > 0.5) {
      v.liquidMesh.visible = true;
      v.surface.visible = true;

      // Update liquid body geometry to perfectly match vessel interior
      v.liquidMesh.geometry.dispose();
      v.liquidMesh.geometry = this.buildLiquidGeometry(v.type, v.baseY, fillH);
      v.liquidMesh.position.set(0, 0, 0);
      v.liquidMesh.scale.set(1, 1, 1);

      // Update surface meniscus disk
      const topR = this.getInnerRadiusAt(v.type, v.baseY + fillH);
      v.surface.geometry.dispose();
      v.surface.geometry = new THREE.CircleGeometry(topR, 36);
      v.surface.position.set(0, v.baseY + fillH, 0);
    } else {
      v.liquidMesh.visible = false;
      v.surface.visible = false;
    }

    if (v.liq) {
      v.liquidMat.color.set(v.liq);
      v.surfaceMat.color.set(v.liq);

      const isClear =
        v.liq === CLEAR ||
        v.liq === "#bde4f7" ||
        v.liq === "#b0def5" ||
        v.liq === "#e2eff7" ||
        v.liq === "#dcedf7" ||
        v.liq === "#dbe8f5";

      if (isClear) {
        v.liquidMat.transmission = 0.82;
        v.liquidMat.opacity = 0.65;
        v.liquidMat.roughness = 0.05;
        v.surfaceMat.opacity = 0.7;
      } else {
        // Deep, rich authentic chemical appearance (CuSO₄, KMnO₄, FeCl₃, Cu(OH)₂, indicators, etc.)
        v.liquidMat.transmission = 0.38;
        v.liquidMat.opacity = 0.94;
        v.liquidMat.roughness = 0.08;
        v.surfaceMat.opacity = 0.95;
      }
    }
    // Only glow thermally if heated strongly on burner above 90°C
    const heatT = Math.max(0, Math.min(1, (v.temp - 90) / 200));
    if (heatT > 0) {
      v.liquidMat.emissive.setRGB(heatT * 0.35, heatT * 0.08, 0);
      v.liquidMat.emissiveIntensity = heatT * 0.6;
    } else {
      v.liquidMat.emissive.setRGB(0, 0, 0);
      v.liquidMat.emissiveIntensity = 0;
    }
    this.refreshLabel(v);
  }

  private spawn(
    kind: ParticleKind,
    pos: THREE.Vector3,
    opts: Partial<Omit<Particle, "type" | "sprite">> & { color?: number } = {},
  ) {
    const mat = new THREE.SpriteMaterial({
      map: this.glowTex,
      color: opts.color ?? 0xffffff,
      transparent: true,
      depthWrite: false,
      blending:
        kind === "smoke" || kind === "steam" ? THREE.NormalBlending : THREE.AdditiveBlending,
      opacity: kind === "smoke" ? 0.18 : kind === "steam" ? 0.12 : 0.9,
    });
    const sprite = new THREE.Sprite(mat);
    const baseR =
      opts.baseR ??
      (kind === "bubble" ? 0.05 : kind === "smoke" ? 0.35 : kind === "flash" ? 0.1 : 0.35);
    sprite.scale.set(baseR, baseR, 1);
    sprite.position.copy(pos);
    this.scene.add(sprite);
    this.particles.push({
      type: kind,
      sprite,
      life: 1,
      maxLife: opts.maxLife ?? 1,
      vx: opts.vx ?? (Math.random() - 0.5) * 0.3,
      vy: opts.vy ?? (kind === "bubble" ? 1.1 : 0.6),
      vz: opts.vz ?? (Math.random() - 0.5) * 0.3,
      maxR: opts.maxR ?? baseR * (kind === "flash" ? 12 : kind === "fireball" ? 3 : 2),
      baseR,
    });
  }

  private startStream(
    src: Vessel,
    tgt: Vessel,
    color: string,
    tick: (dt: number) => void,
    done: () => void,
  ) {
    labAudio.playPour(1.1);

    const tiltDir = Math.sign(tgt.group.position.x - src.group.position.x) || 1;
    // Exactly locate the outer rim lip/spout where liquid flows out of the glass
    let rimRadius = src.innerR + 0.04;
    if (src.type === "beaker") rimRadius = 0.54;
    else if (src.type === "flask") rimRadius = 0.28;
    else if (src.type === "cylinder") rimRadius = 0.38;
    else rimRadius = 0.22;

    const lipLocal = new THREE.Vector3(tiltDir * rimRadius, src.height - 0.02, 0);
    const sp = lipLocal.applyMatrix4(src.group.matrixWorld);

    // Target landing point inside the target vessel
    const tp = tgt.group.position.clone();
    tp.y += tgt.baseY + Math.max(0.12, (tgt.vol / tgt.maxVol) * (tgt.height - 0.12));

    const mid = new THREE.Vector3(
      (sp.x * 2 + tp.x) / 3,
      Math.max(sp.y, tp.y) + 0.12,
      (sp.z + tp.z) / 2,
    );
    const curve = new THREE.QuadraticBezierCurve3(sp, mid, tp);
    const geo = new THREE.TubeGeometry(curve, 44, 0.038, 12, false);
    const mat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(color),
      roughness: 0.06,
      transmission: 0.45,
      transparent: true,
      opacity: 0.92,
      ior: 1.33,
    });
    const mesh = new THREE.Mesh(geo, mat);
    const total = geo.index ? geo.index.count : 0;
    geo.setDrawRange(0, 0);
    this.scene.add(mesh);
    let t = 0;
    let splashTimer = 0;

    const step = (dt: number) => {
      t += dt / 0.95;
      const p = Math.min(1, t);
      geo.setDrawRange(0, Math.floor(total * p));
      if (t > 0.2) {
        tick(dt);
        splashTimer += dt;
        if (splashTimer > 0.08) {
          splashTimer = 0;
          // Spawn liquid micro-droplet along the stream curve
          const dropP = 0.3 + Math.random() * 0.65;
          const dropPos = curve.getPoint(dropP);
          this.spawn("bubble", dropPos, {
            maxLife: 0.28,
            baseR: 0.025,
            vy: -0.4,
            vx: (Math.random() - 0.5) * 0.1,
            color: new THREE.Color(color).getHex(),
          });
        }
      }
      if (t >= 1.05) {
        mat.opacity = Math.max(0, 0.92 - (t - 1.05) * 6);
      }
      if (t >= 1.3) {
        this.scene.remove(mesh);
        geo.dispose();
        mat.dispose();
        for (let i = 0; i < 7; i++) {
          this.spawn(
            "bubble",
            tp
              .clone()
              .add(
                new THREE.Vector3((Math.random() - 0.5) * 0.16, 0.04, (Math.random() - 0.5) * 0.16),
              ),
            {
              maxLife: 0.55,
              baseR: 0.035,
              vy: 0.45,
              color: new THREE.Color(color).getHex(),
            },
          );
        }
        done();
        return false;
      }
      return true;
    };
    this.streams.push(step);
  }

  private streams: ((dt: number) => boolean)[] = [];

  /**
   * Eritmada indikator bo'lsa, rangini aralashmaning real pH'iga qarab yangilaydi:
   * lakmus — kislota: qizil / neytral: binafsha / ishqor: ko'k;
   * fenolftalein — pH≤8.2: rangsiz / pH>8.2: yorqin pushti.
   */
  private applyIndicator(v: Vessel) {
    if (!v.indicator || !v.liq) return;
    const c = indicatorColor(v.indicator, v.pH);
    if (!c || c === v.liq) return;
    v.liq = c;
    const name = v.indicator === "litmus" ? "Lakmus" : "Fenolftalein";
    const tone =
      c === "#e8eef2"
        ? "rangsiz"
        : c === "#e23a3a"
          ? "qizil"
          : c === "#3b6ee0"
            ? "ko'k"
            : c === "#ff2e88"
              ? "yorqin pushti"
              : "binafsha";
    this.cb.onLog(`${name}: pH ${v.pH.toFixed(1)} — ${tone} rang`, "s");
  }

  private applyRxn(tgt: Vessel, rxn: Rxn, amt: number) {
    tgt.liq = rxn.lc;
    tgt.pH = rxn.pH;
    tgt.vol = Math.min(tgt.maxVol, tgt.vol + amt);
    tgt.temp = Math.min(400, tgt.temp + (rxn.heat || 0));
    tgt.label = rxn.eq.split("→")[1]?.trim() ?? tgt.label;
    tgt.chemId = null;
    this.applyIndicator(tgt);
    this.refresh(tgt);
    this.cb.onLog(`${rxn.eq} — ${rxn.note}`, rxn.big ? "e" : "s");
    this.logEqOnBoard(rxn.eq);

    const p0 = tgt.group.position.clone();
    if (rxn.eff.includes("bubble")) {
      for (let i = 0; i < 14; i++) {
        setTimeout(() => {
          this.spawn(
            "bubble",
            p0
              .clone()
              .add(
                new THREE.Vector3((Math.random() - 0.5) * 0.35, 0.3, (Math.random() - 0.5) * 0.35),
              ),
            {
              maxLife: 1.1,
              baseR: 0.04 + Math.random() * 0.05,
              vy: 0.9 + Math.random() * 0.6,
              color: 0xcfe8ff,
            },
          );
        }, i * 55);
      }
    }
    if (rxn.eff.includes("smoke")) {
      for (let i = 0; i < 10; i++) {
        setTimeout(() => {
          this.spawn("smoke", p0.clone().add(new THREE.Vector3(0, tgt.height * 0.8, 0)), {
            maxLife: 1.9,
            baseR: 0.25,
            vy: 0.55,
            color: 0x9aa0b0,
          });
        }, i * 85);
      }
    }
    if (rxn.eff === "explosion" || rxn.eff === "mega_explosion") {
      const isMega = rxn.eff === "mega_explosion";
      setTimeout(() => {
        this.explode(tgt, isMega ? "mega" : "medium");
        this.removeVessel(tgt.id);
      }, 240);
    }
  }

  private explode(v: Vessel, intensity: "pop" | "medium" | "mega" = "medium") {
    const pos = v.group.position.clone();
    pos.y = v.height * 0.6;
    const isMega = intensity === "mega";
    const isPop = intensity === "pop";

    labAudio.playExplosion(intensity);

    // 1. Blinding plasma core flash
    this.spawn("flash", pos, {
      maxLife: isMega ? 0.6 : 0.35,
      baseR: 0.2,
      maxR: isMega ? 7.5 : isPop ? 1.8 : 4.2,
      color: isMega ? 0xfff0b0 : 0xffebd0,
    });

    // 2. High-speed fireball bursts
    const fireCount = isMega ? 18 : isPop ? 3 : 9;
    for (let i = 0; i < fireCount; i++) {
      setTimeout(() => {
        const angle = Math.random() * Math.PI * 2;
        const dist = Math.random() * (isMega ? 1.5 : 0.8);
        this.spawn(
          "fireball",
          pos
            .clone()
            .add(
              new THREE.Vector3(
                Math.cos(angle) * dist,
                Math.random() * (isMega ? 1.2 : 0.6),
                Math.sin(angle) * dist,
              ),
            ),
          {
            maxLife: isMega ? 1.2 : 0.75,
            baseR: isMega ? 0.7 : 0.35,
            maxR: isMega ? 2.4 : 1.2,
            vy: 1.6 + Math.random() * (isMega ? 2.2 : 1.2),
            vx: (Math.random() - 0.5) * (isMega ? 3.0 : 1.5),
            vz: (Math.random() - 0.5) * (isMega ? 3.0 : 1.5),
            color: isMega ? (i % 2 === 0 ? 0xff3b00 : 0xffa010) : 0xff6b10,
          },
        );
      }, i * 30);
    }

    // 3. Dense billowing smoke mushroom cloud
    const smokeCount = isMega ? 26 : isPop ? 6 : 14;
    for (let i = 0; i < smokeCount; i++) {
      setTimeout(() => {
        this.spawn(
          "smoke",
          pos
            .clone()
            .add(new THREE.Vector3((Math.random() - 0.5) * 0.4, 0, (Math.random() - 0.5) * 0.4)),
          {
            maxLife: isMega ? 3.4 : 2.0,
            baseR: 0.3,
            maxR: isMega ? 3.2 : 1.8,
            vy: 0.8 + Math.random() * (isMega ? 1.1 : 0.6),
            vx: (Math.random() - 0.5) * (isMega ? 1.2 : 0.6),
            color: isMega ? 0x4a4a55 : 0x777788,
          },
        );
      }, i * 45);
    }

    // 4. Point light flash illumination
    const lightPower = isMega ? 120 : isPop ? 20 : 50;
    const flash = new THREE.PointLight(0xff9933, lightPower, isMega ? 22 : 12, 1.8);
    flash.position.copy(pos);
    this.scene.add(flash);
    const start = performance.now();
    const flashDur = isMega ? 750 : 400;
    const decay = () => {
      const t = (performance.now() - start) / flashDur;
      flash.intensity = Math.max(0, lightPower * Math.pow(1 - t, 2));
      if (t < 1) requestAnimationFrame(decay);
      else this.scene.remove(flash);
    };
    decay();

    // 5. Realistic cinematic screen shake
    this.shakeMag = isMega ? 0.65 : isPop ? 0.08 : 0.28;
    this.shakeDur = isMega ? 1200 : isPop ? 300 : 700;
    this.shakeStart = performance.now();
  }

  /**
   * A real spill: liquid runs out onto the bench, spreads by its volume, keeps
   * its own chemistry, cools to room temperature and slowly evaporates.
   * If it touches another spill that it can react with, the reaction happens.
   */
  private addSpill(
    x: number,
    z: number,
    color: string,
    vol: number,
    temp: number,
    chemId: string | null,
    label: string,
  ) {
    const mat = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color(color),
      roughness: 0.1,
      metalness: 0,
      transparent: true,
      opacity: 0.78,
      side: THREE.DoubleSide,
      clearcoat: 1,
    });
    const mesh = new THREE.Mesh(new THREE.CircleGeometry(1, 30), mat);
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.set(x, 0.012 + this.puddles.length * 0.0015, z);
    mesh.scale.setScalar(0.05);
    this.scene.add(mesh);
    const p: Puddle = {
      mesh,
      mat,
      vol,
      target: Math.min(1.6, 0.22 + vol / 190),
      grown: 0.05,
      temp,
      chemId,
      label,
    };

    // reacting with a neighbouring spill
    const other = this.puddles.find(
      (o) => Math.hypot(o.mesh.position.x - x, o.mesh.position.z - z) < o.grown + p.target,
    );
    const rxn = other ? findRxn(chemId, other.chemId, label, other.label) : null;
    if (other && rxn) {
      other.vol += vol;
      other.target = Math.min(1.9, 0.22 + other.vol / 190);
      other.chemId = null;
      other.label = rxn.eq.split("→")[1]?.trim() ?? other.label;
      other.temp = Math.min(400, other.temp + rxn.heat * 0.5);
      other.mat.color.set(rxn.lc);
      this.scene.remove(mesh);
      mesh.geometry.dispose();
      mat.dispose();
      this.logEqOnBoard(rxn.eq);
      this.cb.onLog(
        `Stolda to'kilgan suyuqliklar reaksiyaga kirdi: ${rxn.eq}`,
        rxn.big ? "e" : "s",
      );
      for (let i = 0; i < 10; i++) {
        this.spawn("bubble", new THREE.Vector3(other.mesh.position.x, 0.1, other.mesh.position.z), {
          maxLife: 0.7,
          baseR: 0.05,
          vy: 0.7,
          color: 0xdfe9ff,
        });
      }
      if (rxn.eff.includes("smoke") || rxn.heat > 60) {
        for (let i = 0; i < 8; i++) {
          this.spawn(
            "smoke",
            new THREE.Vector3(other.mesh.position.x, 0.2, other.mesh.position.z),
            {
              maxLife: 1.8,
              baseR: 0.2,
              maxR: 1.4,
              vy: 0.5,
              color: 0x9aa0b0,
            },
          );
        }
      }
      return;
    } else if (other) {
      const totalVol = other.vol + vol;
      const w = vol / Math.max(1, totalVol);
      other.vol = totalVol;
      other.target = Math.min(1.9, 0.22 + other.vol / 190);
      other.chemId = null;
      other.label = combineChemicalLabels(other.label, label);
      other.temp = other.temp * (1 - w) + temp * w;
      other.mat.color.set(blendWeightedHex(`#${other.mat.color.getHexString()}`, color, w));
      this.scene.remove(mesh);
      mesh.geometry.dispose();
      mat.dispose();
      this.emit();
      return;
    }
    this.puddles.push(p);
    this.cb.onLog(`${label} stolga to'kildi — ${vol.toFixed(0)}ml`, "w");
    this.emit();
  }

  /** Glass dropped from height: shards fly, liquid spills, vessel is gone. */

  private shatter(v: Vessel) {
    const pos = v.group.position.clone();
    const shardMat = new THREE.MeshPhysicalMaterial({
      color: 0xdce8fb,
      roughness: 0.1,
      metalness: 0,
      transparent: true,
      opacity: 0.55,
      side: THREE.DoubleSide,
      clearcoat: 1,
    });
    for (let i = 0; i < 22; i++) {
      const geo = new THREE.TetrahedronGeometry(0.06 + Math.random() * 0.09);
      const m = new THREE.Mesh(geo, shardMat);
      m.position.set(
        pos.x + (Math.random() - 0.5) * 0.3,
        0.12 + Math.random() * 0.4,
        pos.z + (Math.random() - 0.5) * 0.3,
      );
      m.castShadow = true;
      this.scene.add(m);
      this.shards.push({
        mesh: m,
        vx: (Math.random() - 0.5) * 3.4,
        vy: 1.2 + Math.random() * 2.2,
        vz: (Math.random() - 0.5) * 2.2,
        rx: (Math.random() - 0.5) * 8,
        rz: (Math.random() - 0.5) * 8,
        life: 2.6,
      });
    }
    // spilled liquid puddle
    if (v.liq && v.vol > 0.5) {
      this.addSpill(pos.x, pos.z, v.liq, v.vol, v.temp, v.chemId, v.label);
      for (let i = 0; i < 8; i++) {
        this.spawn("bubble", new THREE.Vector3(pos.x, 0.2, pos.z), {
          maxLife: 0.5,
          baseR: 0.05,
          vy: 0.6,
          color: 0xdfe9ff,
        });
      }
    }

    this.spawn("flash", new THREE.Vector3(pos.x, 0.35, pos.z), {
      maxLife: 0.22,
      baseR: 0.12,
      maxR: 1.1,
      color: 0xe8f4ff,
    });
    labAudio.playClink();
    this.shakeMag = 0.1;
    this.shakeDur = 320;
    this.shakeStart = performance.now();
    this.cb.onLog(`💥 ${v.label} balandlikdan tushib sindi — shisha parchalandi!`, "e");
    this.removeVessel(v.id);
  }

  // ---------------- interaction ----------------
  private setPointer(e: PointerEvent) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  }

  private pickVessel(): Vessel | null {
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hits = this.raycaster.intersectObjects(
      this.vessels.map((v) => v.group),
      true,
    );
    const first = hits[0];
    if (!first) return null;
    let obj: THREE.Object3D | null = first.object;
    while (obj && !this.vessels.some((v) => v.group === obj)) obj = obj.parent;
    return this.vessels.find((v) => v.group === obj) ?? null;
  }

  private pickBurner() {
    this.raycaster.setFromCamera(this.pointer, this.camera);
    return this.raycaster.intersectObject(this.burnerGroup, true).length > 0;
  }

  private planeHit(): THREE.Vector3 | null {
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const pt = new THREE.Vector3();
    return this.raycaster.ray.intersectPlane(this.benchPlane, pt) ? pt : null;
  }

  /** Hit against the vertical plane that contains the bench line (x / y move). */
  private linePlaneHit(): THREE.Vector3 | null {
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const pt = new THREE.Vector3();
    return this.raycaster.ray.intersectPlane(this.linePlane, pt) ? pt : null;
  }

  private onPointerDown = (e: PointerEvent) => {
    this.activePointers.add(e.pointerId);
    // second finger = pinch/orbit gesture, never a drag
    if (this.activePointers.size > 1) {
      this.releaseDrag();
      this.controls.enabled = true;
      return;
    }
    this.setPointer(e);
    this.downPos = { x: e.clientX, y: e.clientY };
    const v = this.pickVessel();
    if (v) {
      this.selId = v.id;
      this.emit();
      const hit = this.linePlaneHit();
      v.held = true;
      v.vy = 0;
      v.peakY = v.group.position.y;
      this.dragging = {
        v,
        offset: hit
          ? new THREE.Vector3(hit.x - v.group.position.x, hit.y - v.group.position.y, 0)
          : new THREE.Vector3(),
      };
      this.dragPointer = e.pointerId;
      this.controls.enabled = false;
      try {
        this.renderer.domElement.setPointerCapture(e.pointerId);
      } catch {
        // ignore
      }
      return;
    }
  };

  private onPointerMove = (e: PointerEvent) => {
    if (this.dragging && e.pointerId !== this.dragPointer) return;
    this.setPointer(e);
    if (this.dragging) {
      const pt = this.linePlaneHit();
      const v = this.dragging.v;
      if (pt) {
        v.group.position.x = THREE.MathUtils.clamp(pt.x - this.dragging.offset.x, -9, 9);
        v.group.position.y = THREE.MathUtils.clamp(pt.y - this.dragging.offset.y, 0, 7.5);
        v.group.position.z = this.LINE_Z;
        v.peakY = Math.max(v.peakY, v.group.position.y);
        v.wobble = 1;
        v.moved = true;
      }
      this.renderer.domElement.style.cursor = "grabbing";
    } else {
      this.renderer.domElement.style.cursor =
        this.pickVessel() || this.pickBurner() ? "pointer" : "default";
    }
  };

  private releaseDrag() {
    if (!this.dragging) return;
    this.dragging.v.held = false;
    this.dragging = null;
    this.dragPointer = null;
  }

  private onPointerUp = (e: PointerEvent) => {
    this.activePointers.delete(e.pointerId);
    try {
      this.renderer.domElement.releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
    if (!this.dragging) {
      const moved = Math.hypot(e.clientX - this.downPos.x, e.clientY - this.downPos.y) > 6;
      if (!moved) {
        this.setPointer(e);
        if (this.pickBurner()) {
          this.toggleBurner();
        }
      }
      this.controls.enabled = true;
      return;
    }
    const v = this.dragging.v;
    const moved = Math.hypot(e.clientX - this.downPos.x, e.clientY - this.downPos.y) > 5;
    let pourTriggered = false;

    // Pouring is triggered when the held vessel has liquid, is lifted slightly, and brought over/near another vessel
    if (moved && v.liq && v.vol > 0.5) {
      const near = this.vessels.find(
        (o) =>
          o.id !== v.id &&
          Math.abs(o.group.position.x - v.group.position.x) <
            this.footprint(v) + this.footprint(o) + 0.55 &&
          v.group.position.y >= o.group.position.y + 0.15,
      );
      if (near) {
        pourTriggered = true;
        this.cb.onPourRequest(v.id, near.id);
      }
    }
    this.releaseDrag();
    if (!pourTriggered) {
      const safeX = this.freeSpot(v, v.group.position.x);
      if (Math.abs(safeX - v.group.position.x) > 0.04) {
        v.group.position.x = safeX;
      }
      this.separate();
    }
    this.controls.enabled = true;
  };

  private resize() {
    const w = this.mount.clientWidth || 1;
    const h = this.mount.clientHeight || 1;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    this.labelRenderer.setSize(w, h);
    this.composer.setSize(w, h);
    this.bloom.setSize(w, h);
  }

  private animate = (now: number) => {
    this.raf = requestAnimationFrame(this.animate);
    const dt = Math.min(0.05, (now - this.last) / 1000);
    this.last = now;
    const t = now / 1000;

    this.controls.update();
    const activeStreams = [...this.streams];
    this.streams = [];
    const remaining: ((dt: number) => boolean)[] = [];
    for (const s of activeStreams) {
      if (s(dt)) {
        remaining.push(s);
      }
    }
    this.streams.push(...remaining);

    // burner
    const target = this.burnerOn ? 1 : 0;
    this.flameLight.intensity +=
      ((this.burnerOn ? 3.6 : 0) - this.flameLight.intensity) * Math.min(1, dt * 6);
    this.flameSprites.forEach((s, i) => {
      const m = s.material as THREE.SpriteMaterial;
      m.opacity += (target * (0.5 + 0.35 * Math.sin(t * 9 + i)) - m.opacity) * Math.min(1, dt * 8);
      const h = 0.5 + Math.sin(t * 6 + i * 1.3) * 0.15;
      const inner = i < 2 ? 0.6 : 1;
      s.scale.set((0.34 - i * 0.025) * inner, ((0.5 + h) * target + 0.001) * inner, 1);
      s.position.set(Math.sin(t * 4 + i) * 0.05, 0.2 + i * 0.09, Math.cos(t * 3 + i) * 0.05);
    });

    let dirty = false;
    for (const v of [...this.vessels]) {
      const overBurner = Math.abs(v.group.position.x - this.BRN.x) < 1.05;
      const restY = overBurner ? this.GAUZE_Y : 0;
      const onBurner = overBurner && v.group.position.y <= restY + 0.15;

      // real gravity: lifted glass falls back to the bench or onto the gauze
      if (!v.held) {
        if (v.group.position.y > restY + 0.001 || v.vy !== 0) {
          v.vy -= 12 * dt;
          v.group.position.y += v.vy * dt;
          if (v.group.position.y <= restY) {
            const impact = Math.abs(v.vy);
            v.group.position.y = restY;
            v.vy = 0;
            v.wobble = 1;
            if (v.peakY - restY > this.BREAK_Y) {
              this.shatter(v);
              dirty = true;
              continue;
            }
            if (impact > 1.2) this.cb.onLog(`${v.label} stolga qo'yildi (tuk!)`, "i");
            v.peakY = restY;
          }
        } else {
          v.group.position.y = restY;
          v.peakY = restY;
        }
      }
      // ---- real heat transfer: flame setpoint, thermal mass, boiling plateau ----
      const prev = v.temp;
      const liquid = v.vol > 0.5;
      // thermal mass: more liquid heats slower, empty glass heats fast
      const mass = liquid ? 0.35 + v.vol / 120 : 0.18;
      if (onBurner && this.burnerOn) {
        const drive = (this.burnerTemp - v.temp) * (0.55 / mass) * dt;
        v.temp = Math.min(this.burnerTemp, v.temp + Math.max(0, drive));
        // while boiling, all extra energy goes into vaporisation — temperature holds
        if (liquid && v.temp > v.boil) v.temp = v.boil;
      } else {
        // Newton cooling toward room temperature
        v.temp = 22 + (v.temp - 22) * Math.exp(-(0.35 / mass) * dt);
      }
      if (Math.abs(prev - v.temp) > 0.001) this.refresh(v);
      if (Math.floor(prev) !== Math.floor(v.temp)) dirty = true;

      // empty glass on an open flame: thermal shock cracks it
      if (!liquid && onBurner && this.burnerOn && v.temp > 480) {
        this.cb.onLog(`${v.label} bo'sh holda qizdirildi — termik zarbadan yorildi!`, "e");
        this.shatter(v);
        dirty = true;
        continue;
      }

      // liquid wobble / sloshing
      if (v.wobble > 0.001) {
        v.wobble = Math.max(0, v.wobble - dt * 1.6);
        const a = v.wobble * 0.08;
        v.liquidMesh.rotation.z = Math.sin(t * 14) * a;
        v.surface.rotation.z = Math.sin(t * 14) * a;
      }

      // boiling + evaporation
      if (v.vol > 0.5 && v.temp >= v.boil) {
        v.bubbleT += dt;
        if (v.bubbleT > 0.05) {
          v.bubbleT = 0;
          const r = v.innerR * Math.random();
          const a = Math.random() * Math.PI * 2;
          this.spawn(
            "bubble",
            v.group.position
              .clone()
              .add(new THREE.Vector3(Math.cos(a) * r, v.baseY + 0.05, Math.sin(a) * r)),
            { maxLife: 0.7, baseR: 0.03 + Math.random() * 0.04, vy: 1.4, color: 0xe8f4ff },
          );
          if (Math.random() < 0.5) {
            this.spawn(
              "steam",
              v.group.position.clone().add(new THREE.Vector3(0, v.height * 0.95, 0)),
              {
                maxLife: 1.6,
                baseR: 0.2,
                maxR: 1.1,
                vy: 0.8,
                color: 0xdfe8f5,
              },
            );
          }
          // stronger flame boils it away faster (latent-heat driven rate)
          const over = onBurner && this.burnerOn ? Math.max(0, this.burnerTemp - v.boil) : 0;
          v.vol = Math.max(0, v.vol - (0.12 + over / 900));
          if (v.vol < 0.5) {
            v.vol = 0;
            v.liq = null;
            v.chemId = null;
            this.cb.onLog(`${v.label} to'liq bug'landi — quruq qoldiq qoldi`, "w");
          }
          this.refresh(v);
          dirty = true;
        }
      }
    }

    // continuous anti-stacking & collision separation for resting vessels
    const grounded = this.vessels.filter(
      (x) => !x.held && !this.busy.has(x.id) && x.group.position.y <= 0.15,
    );
    for (let i = 0; i < grounded.length; i++) {
      for (let j = i + 1; j < grounded.length; j++) {
        const a = grounded[i]!;
        const b = grounded[j]!;
        const minG = this.minGap(a, b);
        const diff = b.group.position.x - a.group.position.x;
        const dist = Math.abs(diff);
        if (dist < minG - 0.001) {
          const overlap = (minG - dist) * 0.5;
          const dir = diff >= 0 ? 1 : -1;
          const pushAmount = Math.min(overlap, overlap * dt * 10 + 0.01);
          a.group.position.x = THREE.MathUtils.clamp(
            a.group.position.x - dir * pushAmount,
            -9.2,
            9.2,
          );
          b.group.position.x = THREE.MathUtils.clamp(
            b.group.position.x + dir * pushAmount,
            -9.2,
            9.2,
          );
          a.moved = true;
          b.moved = true;
          dirty = true;
        }
      }
    }

    if (dirty) this.emit();

    // spills on the bench: they spread, cool down and slowly evaporate
    let spillDirty = false;
    for (let i = this.puddles.length - 1; i >= 0; i--) {
      const p = this.puddles[i]!;
      if (p.grown < p.target) {
        p.grown = Math.min(p.target, p.grown + dt * 0.9);
        p.mesh.scale.setScalar(p.grown);
      }
      p.temp = 22 + (p.temp - 22) * Math.exp(-0.5 * dt);
      // thin film evaporates: hot spills go quicker
      const rate = 0.55 + Math.max(0, p.temp - 22) * 0.05;
      p.vol -= rate * dt;
      if (p.temp > 60 && Math.random() < dt * 3) {
        this.spawn("steam", new THREE.Vector3(p.mesh.position.x, 0.08, p.mesh.position.z), {
          maxLife: 1.4,
          baseR: 0.16,
          maxR: 0.9,
          vy: 0.55,
          color: 0xdfe8f5,
        });
      }
      p.target = Math.min(p.target, 0.22 + Math.max(0, p.vol) / 190);
      p.grown = Math.min(p.grown, p.target);
      p.mesh.scale.setScalar(Math.max(0.02, p.grown));
      p.mat.opacity = Math.max(0, Math.min(0.78, p.vol / 12));
      if (p.vol <= 0) {
        this.scene.remove(p.mesh);
        p.mesh.geometry.dispose();
        p.mat.dispose();
        this.puddles.splice(i, 1);
        this.cb.onLog(`${p.label} dog'i bug'lanib quridi`, "i");
        spillDirty = true;
      }
    }
    if (spillDirty) this.emit();

    // glass shards
    for (let i = this.shards.length - 1; i >= 0; i--) {
      const s = this.shards[i]!;
      s.vy -= 13 * dt;
      s.mesh.position.x += s.vx * dt;
      s.mesh.position.y += s.vy * dt;
      s.mesh.position.z += s.vz * dt;
      s.mesh.rotation.x += s.rx * dt;
      s.mesh.rotation.z += s.rz * dt;
      if (s.mesh.position.y < 0.04) {
        s.mesh.position.y = 0.04;
        s.vy *= -0.28;
        s.vx *= 0.6;
        s.vz *= 0.6;
        s.rx *= 0.5;
        s.rz *= 0.5;
      }
      s.life -= dt;
      if (s.life < 0.8) {
        const m = s.mesh.material as THREE.MeshPhysicalMaterial;
        m.opacity = Math.max(0, (s.life / 0.8) * 0.55);
      }
      if (s.life <= 0) {
        this.scene.remove(s.mesh);
        s.mesh.geometry.dispose();
        this.shards.splice(i, 1);
      }
    }

    // particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i]!;
      p.life -= dt / p.maxLife;
      p.sprite.position.x += p.vx * dt;
      p.sprite.position.y += p.vy * dt;
      p.sprite.position.z += p.vz * dt;
      if (p.type === "flash") {
        const s = p.baseR + (1 - p.life) * p.maxR;
        p.sprite.scale.set(s, s, 1);
      } else if (p.type === "fireball" || p.type === "smoke" || p.type === "steam") {
        const s = p.baseR + (1 - p.life) * p.maxR;
        p.sprite.scale.set(s, s, 1);
        p.vy *= 1 - dt * 0.4;
      }
      (p.sprite.material as THREE.SpriteMaterial).opacity =
        Math.max(0, p.life) * (p.type === "smoke" ? 0.18 : p.type === "steam" ? 0.13 : 0.9);
      if (p.life <= 0) {
        this.scene.remove(p.sprite);
        (p.sprite.material as THREE.Material).dispose();
        this.particles.splice(i, 1);
      }
    }

    // camera shake
    const elapsed = performance.now() - this.shakeStart;
    if (elapsed < this.shakeDur) {
      const decay = 1 - elapsed / this.shakeDur;
      this.camera.position.x += (Math.random() - 0.5) * this.shakeMag * decay;
      this.camera.position.y += (Math.random() - 0.5) * this.shakeMag * decay;
    }

    this.composer.render();
    this.labelRenderer.render(this.scene, this.camera);
  };
}
