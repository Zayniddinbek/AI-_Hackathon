# 3D Chemistry Lab

menga 3d cross platforma kerak yani foydalanuvchilar 3d muhitda istalgan ishini bajarib natijani hayotdagidek 1 ga 1 holatda korishi kerak men ozgina kodini boshlab qoyganman mukammal emas har bitta narsa hattiki probilka ham hayotiy bolsin

import React, { useEffect, useRef } from 'react';
import { useNavigation } from '../../context/NavigationContext';
import { ArrowLeft } from 'lucide-react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';

// =====================================================================
// Tozalik/Kimyo laboratoriyasi — haqiqiy 3D versiya (Three.js).
// Kimyo bazasi va reaksiya jadvali original 2D versiyadan bir xil
// saqlangan — faqat render qatlami butunlay 3D ga o'tkazilgan:
// shisha idishlar hajmli (transmission) material bilan, alanga/portlash
// uchun bloom post-processing, CSS2D yorliqlar va sinf darajasidagi
// yorug'lik sxemasi bilan.
// =====================================================================

type ChemType = 'acid' | 'base' | 'indicator' | 'salt' | 'metal' | 'water' | 'oxidizer' | 'organic';
interface Chem {
id: string; f: string; n: string; color: string; bg: string;
pH: number; cat: string; type: ChemType; density: number; boil: number;
}
interface Rxn {
r1: string; r2: string; type: string; eq: string; lc: string; pH: number;
eff: string; note: string; heat: number; big?: boolean;
}
type VesselType = 'beaker' | 'flask' | 'test_tube' | 'cylinder';
interface Vessel {
id: string; type: VesselType; chemId: string | null; label: string;
x: number; z: number; liq: string | null; vol: number; pH: number; temp: number;
group: THREE.Group; liquidMesh: THREE.Mesh; liquidMat: THREE.MeshPhysicalMaterial;
labelEl: HTMLDivElement; labelObj: CSS2DObject; maxVol: number; height: number;
}
type ParticleKind = 'bubble' | 'smoke' | 'flash' | 'fireball';
interface Particle {
type: ParticleKind; sprite: THREE.Sprite; life: number; maxLife: number;
vx: number; vy: number; vz: number; maxR: number; baseR: number;
}

export default function ChemistryLab3D() {
const { navigateToHome } = useNavigation();
const mountRef = useRef(null);
const overlayRef = useRef(null);

useEffect(() => {
if (!mountRef.current || !overlayRef.current) return;
const mount = mountRef.current;

    // ================= DATABASE (unchanged chemistry) =================
    const CHEMS: Record<'acids' | 'bases' | 'others', Chem[]> = {
      acids: [
        { id: 'hcl', f: 'HCl', n: 'Xlorid kislota', color: '#5bc4e8', bg: 'rgba(20,60,100,0.6)', pH: 1, cat: 'K', type: 'acid', density: 1.19, boil: 110 },
        { id: 'h2so4', f: 'H₂SO₄', n: 'Sulfat kislota', color: '#e8c85b', bg: 'rgba(80,60,10,0.6)', pH: 0.5, cat: 'K', type: 'acid', density: 1.84, boil: 337 },
        { id: 'hno3', f: 'HNO₃', n: 'Nitrat kislota', color: '#ff9a45', bg: 'rgba(80,40,10,0.6)', pH: 1, cat: 'K', type: 'acid', density: 1.51, boil: 86 },
        { id: 'hclo4', f: 'HClO₄', n: 'Perxlor kislota', color: '#e8d0e8', bg: 'rgba(60,30,60,0.5)', pH: 0, cat: 'K', type: 'acid', density: 1.77, boil: 203 },
      ],
      bases: [
        { id: 'naoh', f: 'NaOH', n: 'Natriy gidroksid', color: '#5be8a0', bg: 'rgba(10,70,40,0.6)', pH: 13, cat: 'I', type: 'base', density: 2.13, boil: 1390 },
        { id: 'koh', f: 'KOH', n: 'Kaliy gidroksid', color: '#5be8c0', bg: 'rgba(10,70,55,0.6)', pH: 13, cat: 'I', type: 'base', density: 2.04, boil: 1327 },
        { id: 'caoh2', f: 'Ca(OH)₂', n: 'Kaltsiy gidroksid', color: '#aaeedd', bg: 'rgba(20,70,55,0.5)', pH: 12, cat: 'I', type: 'base', density: 2.21, boil: 580 },
        { id: 'nh3', f: 'NH₃', n: 'Ammiak eritmasi', color: '#b0e8b0', bg: 'rgba(15,60,15,0.5)', pH: 11, cat: 'I', type: 'base', density: 0.9, boil: 38 },
      ],
      others: [
        { id: 'phenol', f: 'Fenolftalein', n: 'Indikator', color: '#e85bd8', bg: 'rgba(70,10,70,0.5)', pH: 7, cat: 'IND', type: 'indicator', density: 1.0, boil: 100 },
        { id: 'litmus', f: 'Lakmus', n: 'Indikator', color: '#c05be8', bg: 'rgba(55,10,85,0.5)', pH: 7, cat: 'IND', type: 'indicator', density: 1.0, boil: 100 },
        { id: 'cuso4', f: 'CuSO₄', n: 'Mis sulfat', color: '#3b7bff', bg: 'rgba(15,25,85,0.5)', pH: 4, cat: 'TUZ', type: 'salt', density: 3.6, boil: 150 },
        { id: 'fecl3', f: 'FeCl₃', n: 'Temir(III) xlorid', color: '#c86020', bg: 'rgba(65,25,8,0.5)', pH: 3, cat: 'TUZ', type: 'salt', density: 2.9, boil: 316 },
        { id: 'kmno4', f: 'KMnO₄', n: 'Kaliy permanganat', color: '#9b20d5', bg: 'rgba(45,8,65,0.5)', pH: 7, cat: 'TUZ', type: 'salt', density: 2.7, boil: 240 },
        { id: 'na_metal', f: 'Na', n: 'Natriy metall', color: '#e0e0b0', bg: 'rgba(55,55,20,0.6)', pH: 7, cat: 'ME', type: 'metal', density: 0.97, boil: 883 },
        { id: 'k_metal', f: 'K', n: 'Kaliy metall', color: '#d0e0b0', bg: 'rgba(40,55,15,0.6)', pH: 7, cat: 'ME', type: 'metal', density: 0.89, boil: 759 },
        { id: 'h2o', f: 'H₂O', n: 'Suv', color: '#7ab8e8', bg: 'rgba(15,35,65,0.5)', pH: 7, cat: 'SV', type: 'water', density: 1.0, boil: 100 },
        { id: 'h2o2', f: 'H₂O₂', n: 'Vodorod peroksid', color: '#c8d8f8', bg: 'rgba(20,30,70,0.5)', pH: 6, cat: 'OK', type: 'oxidizer', density: 1.45, boil: 150 },
        { id: 'ethanol', f: 'C₂H₅OH', n: 'Etanol (spirt)', color: '#f0e0a0', bg: 'rgba(60,50,10,0.5)', pH: 7, cat: 'OR', type: 'organic', density: 0.79, boil: 78 },
      ],
    };

    const REACTIONS: Rxn[] = [
      { r1: 'hcl', r2: 'naoh', type: 'Neytrallanish', eq: 'HCl + NaOH → NaCl + H₂O', lc: '#80f0b0', pH: 7, eff: 'bubble', note: 'Neytrallanish — NaCl + H₂O! ΔH=-57kJ/mol', heat: 25 },
      { r1: 'hcl', r2: 'koh', type: 'Neytrallanish', eq: 'HCl + KOH → KCl + H₂O', lc: '#80f0c0', pH: 7, eff: 'bubble', note: 'Neytrallanish reaksiyasi!', heat: 18 },
      { r1: 'h2so4', r2: 'naoh', type: 'Neytrallanish', eq: 'H₂SO₄+2NaOH→Na₂SO₄+2H₂O', lc: '#c0f080', pH: 7, eff: 'bubble+smoke', note: 'Kuchli ekzotermik! ΔH=-114kJ/mol', heat: 70 },
      { r1: 'h2so4', r2: 'koh', type: 'Neytrallanish', eq: 'H₂SO₄+2KOH→K₂SO₄+2H₂O', lc: '#b0f090', pH: 7, eff: 'bubble+smoke', note: 'Kuchli neytrallanish!', heat: 65 },
      { r1: 'hcl', r2: 'caoh2', type: "Neytrallanish+Cho'kma", eq: '2HCl+Ca(OH)₂→CaCl₂+2H₂O', lc: '#b0f0d0', pH: 7, eff: 'precipitate', note: "Cho'kma hosil bo'ldi!", heat: 12 },
      { r1: 'naoh', r2: 'phenol', type: 'Indikator', eq: 'NaOH + Fenolftalein → Qizil', lc: '#ff50c0', pH: 13, eff: 'color', note: 'Ishqoriy muhit — fenolftalein qizil!', heat: 0 },
      { r1: 'hcl', r2: 'phenol', type: 'Indikator', eq: 'HCl + Fenolftalein → Rangsiz', lc: 'rgba(200,210,240,0.1)', pH: 1, eff: 'color', note: 'Kislotali muhit — rangsiz.', heat: 0 },
      { r1: 'koh', r2: 'phenol', type: 'Indikator', eq: 'KOH + Fenolftalein → Qizil', lc: '#ff50d0', pH: 13, eff: 'color', note: 'Ishqoriy muhit — fenolftalein qizil!', heat: 0 },
      { r1: 'hcl', r2: 'litmus', type: 'Indikator', eq: 'HCl + Lakmus → Qizil', lc: '#ff4040', pH: 1, eff: 'color', note: "Kislotali muhit — lakmus qizil!", heat: 0 },
      { r1: 'naoh', r2: 'litmus', type: 'Indikator', eq: "NaOH + Lakmus → Ko'k", lc: '#4060ff', pH: 13, eff: 'color', note: "Ishqoriy muhit — lakmus ko'k!", heat: 0 },
      { r1: 'na_metal', r2: 'h2o', type: '⚠ PORTLASH', eq: '2Na+2H₂O→2NaOH+H₂↑', lc: '#ff8020', pH: 13, eff: 'explosion', note: '⚠️ XAVFLI! Kuchli portlash!', heat: 500, big: true },
      { r1: 'k_metal', r2: 'h2o', type: '⚠ KUCHLI PORTLASH', eq: '2K+2H₂O→2KOH+H₂↑', lc: '#ff4000', pH: 14, eff: 'mega_explosion', note: "💥 O'ta xavfli! Kaliy suv bilan — KUCHLI PORTLASH!", heat: 800, big: true },
      { r1: 'k_metal', r2: 'hcl', type: '⚠ MEGA PORTLASH', eq: '2K+2HCl→2KCl+H₂↑', lc: '#ff2000', pH: 7, eff: 'mega_explosion', note: '💥💥 MEGA PORTLASH! Kaliy+Kislota!', heat: 1000, big: true },
      { r1: 'na_metal', r2: 'hcl', type: '⚠ PORTLASH', eq: '2Na+2HCl→2NaCl+H₂↑', lc: '#ff6010', pH: 7, eff: 'explosion', note: '⚠️ Portlash! Metall + kislota!', heat: 600, big: true },
      { r1: 'na_metal', r2: 'h2so4', type: '⚠ KUCHLI PORTLASH', eq: '2Na+H₂SO₄→Na₂SO₄+H₂↑', lc: '#ff4000', pH: 7, eff: 'mega_explosion', note: '💥 Natriy sulfat kislota bilan!', heat: 700, big: true },
      { r1: 'ethanol', r2: 'h2so4', type: 'Ekzotermik', eq: 'C₂H₅OH+H₂SO₄→ester', lc: '#f0c040', pH: 2, eff: 'heat+smoke', note: 'Ekzotermik reaksiya — ester hosil!', heat: 80 },
      { r1: 'ethanol', r2: 'kmno4', type: 'Oksidlanish', eq: 'C₂H₅OH+KMnO₄→oksidlanish', lc: '#806000', pH: 5, eff: 'color+bubble', note: 'Spirt oksidlanishi!', heat: 30 },
      { r1: 'cuso4', r2: 'naoh', type: "Cho'kma", eq: 'CuSO₄+2NaOH→Cu(OH)₂↓+Na₂SO₄', lc: '#1040ff', pH: 9, eff: 'precipitate', note: "Ko'k cho'kma: Cu(OH)₂!", heat: 5 },
      { r1: 'fecl3', r2: 'naoh', type: "Cho'kma", eq: 'FeCl₃+3NaOH→Fe(OH)₃↓+3NaCl', lc: '#b84000', pH: 9, eff: 'precipitate', note: "Jigarrang cho'kma: Fe(OH)₃!", heat: 5 },
      { r1: 'kmno4', r2: 'h2so4', type: 'Oksidlanish', eq: '2KMnO₄+H₂SO₄→oksidlanish', lc: '#400060', pH: 2, eff: 'color+smoke+bubble', note: 'Kuchli oksidlovchi reaksiya!', heat: 30 },
      { r1: 'h2so4', r2: 'h2o', type: 'Suyultirish', eq: 'H₂SO₄+H₂O→suyultirilgan H₂SO₄', lc: 'rgba(220,200,80,0.5)', pH: 2, eff: 'heat+bubble', note: "⚠️ Ekzotermik! Kislotani suvga qo'shing!", heat: 95 },
      { r1: 'h2o2', r2: 'kmno4', type: 'Oksidlanish', eq: 'H₂O₂+KMnO₄→O₂↑+H₂O', lc: '#f0e8ff', pH: 7, eff: 'bubble+smoke', note: 'Kislorod ajralib chiqadi! O₂↑', heat: 40 },
      { r1: 'h2o2', r2: 'fecl3', type: 'Kataliz', eq: 'H₂O₂→H₂O+½O₂↑ (kat:Fe)', lc: '#e8f0ff', pH: 6, eff: 'bubble', note: 'Fenton reaksiyasi — tez kislorod!', heat: 20 },
      { r1: 'nh3', r2: 'hcl', type: 'Neytrallanish', eq: 'NH₃+HCl→NH₄Cl (oq tutun)', lc: '#f0f0f0', pH: 7, eff: 'smoke+bubble', note: 'Ammoniy xlorid — oq tutun!', heat: 12 },
      { r1: 'cuso4', r2: 'nh3', type: 'Kompleks', eq: 'CuSO₄+4NH₃→[Cu(NH₃)₄]SO₄', lc: '#0060ff', pH: 10, eff: 'color', note: "Tetraaminomis(II) — tuyaqush ko'k!", heat: 5 },
    ];

    function findRxn(a: string | null, b: string | null) {
      if (!a || !b) return null;
      return REACTIONS.find(r => (r.r1 === a && r.r2 === b) || (r.r1 === b && r.r2 === a)) || null;
    }
    function getChem(id: string | null): Chem | null {
      if (!id) return null;
      for (const g of Object.values(CHEMS)) {
        const c = g.find(x => x.id === id);
        if (c) return c;
      }
      return null;
    }
    function blendHex(c1: string, c2: string): string {
      const p = (c: string) => {
        const m = /^#([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(c);
        return m ? [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)] : [120, 160, 220];
      };
      const a = p(c1), b = p(c2);
      const r = Math.round((a[0] + b[0]) / 2), g = Math.round((a[1] + b[1]) / 2), bl = Math.round((a[2] + b[2]) / 2);
      return `#${[r, g, bl].map(v => v.toString(16).padStart(2, '0')).join('')}`;
    }

    // ================= RENDERER / SCENE =================
    const W = () => mount.clientWidth, H = () => mount.clientHeight;
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setSize(W(), H());
    mount.appendChild(renderer.domElement);

    const labelRenderer = new CSS2DRenderer();
    labelRenderer.setSize(W(), H());
    labelRenderer.domElement.style.position = 'absolute';
    labelRenderer.domElement.style.top = '0';
    labelRenderer.domElement.style.left = '0';
    labelRenderer.domElement.style.pointerEvents = 'none';
    mount.appendChild(labelRenderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x05070d);
    scene.fog = new THREE.FogExp2(0x05070d, 0.028);

    const camera = new THREE.PerspectiveCamera(42, W() / H(), 0.1, 200);
    camera.position.set(0, 8.2, 12.5);

    const controls = new OrbitControls(camera, labelRenderer.domElement);
    controls.target.set(0, 2.0, 0);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minDistance = 6;
    controls.maxDistance = 20;
    controls.maxPolarAngle = Math.PI * 0.49;
    controls.minPolarAngle = Math.PI * 0.15;
    controls.enablePan = false;
    controls.update();

    // Bloom compositing for flame / glow / explosion highlights
    const composer = new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene, camera));
    const bloom = new UnrealBloomPass(new THREE.Vector2(W(), H()), 0.85, 0.55, 0.15);
    composer.addPass(bloom);

    // ---------- Lighting ----------
    scene.add(new THREE.HemisphereLight(0x3a4a7a, 0x05060a, 1.15));
    const key = new THREE.DirectionalLight(0xbfd4ff, 1.6);
    key.position.set(-6, 12, 6);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    key.shadow.camera.left = -12; key.shadow.camera.right = 12;
    key.shadow.camera.top = 12; key.shadow.camera.bottom = -12;
    key.shadow.bias = -0.0015;
    scene.add(key);
    const rim = new THREE.DirectionalLight(0x4fa8ff, 0.5);
    rim.position.set(8, 5, -8);
    scene.add(rim);

    // ---------- Lab bench ----------
    const benchGroup = new THREE.Group();
    scene.add(benchGroup);

    const benchTopMat = new THREE.MeshStandardMaterial({ color: 0x1c2230, roughness: 0.35, metalness: 0.55 });
    const bench = new THREE.Mesh(new THREE.BoxGeometry(20, 0.5, 5.2), benchTopMat);
    bench.position.set(0, -0.25, 0);
    bench.receiveShadow = true;
    benchGroup.add(bench);

    const legMat = new THREE.MeshStandardMaterial({ color: 0x0d1018, roughness: 0.5, metalness: 0.6 });
    for (const lx of [-9.3, 9.3]) {
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.4, 4.2, 4.6), legMat);
      leg.position.set(lx, -2.35, 0);
      leg.receiveShadow = true; leg.castShadow = true;
      benchGroup.add(leg);
    }
    // Edge glow strip (signature accent)
    const stripMat = new THREE.MeshStandardMaterial({ color: 0x2a3550, emissive: 0x2f7bd8, emissiveIntensity: 1.4, roughness: 0.4 });
    const strip = new THREE.Mesh(new THREE.BoxGeometry(19.6, 0.04, 0.06), stripMat);
    strip.position.set(0, 0.001, 2.58);
    benchGroup.add(strip);

    // Back wall
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x0a0d16, roughness: 0.9 });
    const wall = new THREE.Mesh(new THREE.PlaneGeometry(40, 16), wallMat);
    wall.position.set(0, 5.5, -6);
    wall.receiveShadow = true;
    scene.add(wall);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(60, 40), new THREE.MeshStandardMaterial({ color: 0x070a12, roughness: 1 }));
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -4.5;
    floor.receiveShadow = true;
    scene.add(floor);

    // ---------- Particle sprite texture (radial glow, reused/tinted) ----------
    function makeGlowTexture() {
      const c = document.createElement('canvas'); c.width = 128; c.height = 128;
      const ctx = c.getContext('2d')!;
      const g = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
      g.addColorStop(0, 'rgba(255,255,255,1)');
      g.addColorStop(0.35, 'rgba(255,255,255,0.55)');
      g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, 128, 128);
      const tex = new THREE.CanvasTexture(c);
      tex.colorSpace = THREE.SRGBColorSpace;
      return tex;
    }
    const glowTex = makeGlowTexture();

    // ---------- Bunsen burner ----------
    let burnerOn = false;
    const BRN = { x: 0, y: 0, z: 1.1 };
    const burnerGroup = new THREE.Group();
    burnerGroup.position.set(BRN.x, 0, BRN.z);
    benchGroup.add(burnerGroup);

    const burnerMetalMat = new THREE.MeshStandardMaterial({ color: 0x20222c, roughness: 0.35, metalness: 0.85 });
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.0, 0.18, 28), burnerMetalMat);
    base.position.y = 0.09; base.castShadow = true; base.receiveShadow = true;
    burnerGroup.add(base);
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.16, 1.1, 16), burnerMetalMat);
    stem.position.y = 0.18 + 0.55; stem.castShadow = true;
    burnerGroup.add(stem);
    const collar = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.1, 16), burnerMetalMat);
    collar.position.y = 1.18;
    burnerGroup.add(collar);
    for (let i = 0; i < 3; i++) {
      const a = (i / 3) * Math.PI * 2;
      const legM = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.35, 8), burnerMetalMat);
      legM.position.set(Math.cos(a) * 0.75, 0.6, Math.sin(a) * 0.75);
      legM.rotation.z = Math.cos(a) * -0.55;
      legM.rotation.x = Math.sin(a) * 0.55;
      legM.castShadow = true;
      burnerGroup.add(legM);
    }
    const flameLight = new THREE.PointLight(0xff8a2a, 0, 6, 2);
    flameLight.position.set(0, 1.5, 0);
    burnerGroup.add(flameLight);

    const flameSprites: THREE.Sprite[] = [];
    const flameGroup = new THREE.Group();
    flameGroup.position.y = 1.25;
    burnerGroup.add(flameGroup);
    for (let i = 0; i < 5; i++) {
      const mat = new THREE.SpriteMaterial({ map: glowTex, color: 0xff9a2a, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0 });
      const spr = new THREE.Sprite(mat);
      spr.scale.set(0.5, 0.8, 1);
      flameGroup.add(spr);
      flameSprites.push(spr);
    }

    // ---------- Vessel factory ----------
    const glassEnvColor = 0x0a0d16;
    function glassMaterial(): THREE.MeshPhysicalMaterial {
      return new THREE.MeshPhysicalMaterial({
        color: 0xdfe9ff, metalness: 0, roughness: 0.04, transmission: 1, thickness: 0.35,
        ior: 1.45, transparent: true, opacity: 1, side: THREE.DoubleSide,
        clearcoat: 0.6, clearcoatRoughness: 0.1, envMapIntensity: 1.2,
      });
    }
    function liquidMaterial(colorHex: string): THREE.MeshPhysicalMaterial {
      return new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(colorHex || '#5590c8'), roughness: 0.12, transmission: 0.55,
        thickness: 0.6, ior: 1.33, transparent: true, opacity: 0.92, side: THREE.DoubleSide,
      });
    }

    function buildBeaker(): { shell: THREE.Object3D; liquid: THREE.Mesh; height: number; maxVol: number } {
      const height = 1.7, rTop = 0.58, rBot = 0.5;
      const shell = new THREE.Mesh(new THREE.CylinderGeometry(rTop, rBot, height, 28, 1, true), glassMaterial());
      shell.position.y = height / 2; shell.castShadow = true;
      const bottom = new THREE.Mesh(new THREE.CircleGeometry(rBot, 28), glassMaterial());
      bottom.rotation.x = -Math.PI / 2; bottom.position.y = 0.005;
      const rim = new THREE.Mesh(new THREE.TorusGeometry(rTop, 0.015, 8, 28), new THREE.MeshStandardMaterial({ color: 0xdfe9ff, roughness: 0.2, metalness: 0.1 }));
      rim.rotation.x = Math.PI / 2; rim.position.y = height;
      const g = new THREE.Group(); g.add(shell, bottom, rim);
      const liquid = new THREE.Mesh(new THREE.CylinderGeometry(rBot * 0.9, rBot * 0.9, 1, 28), liquidMaterial('#5590c8'));
      liquid.userData.baseY = 0.02;
      g.add(liquid);
      return { shell: g, liquid, height, maxVol: 300 };
    }
    function buildFlask(): { shell: THREE.Object3D; liquid: THREE.Mesh; height: number; maxVol: number } {
      const pts = [
        new THREE.Vector2(0, 0), new THREE.Vector2(0.56, 0.06), new THREE.Vector2(0.62, 0.34),
        new THREE.Vector2(0.6, 0.6), new THREE.Vector2(0.17, 1.25), new THREE.Vector2(0.135, 1.58),
        new THREE.Vector2(0.135, 1.68),
      ];
      const height = 1.68;
      const shell = new THREE.Mesh(new THREE.LatheGeometry(pts, 28), glassMaterial());
      shell.castShadow = true;
      const rim = new THREE.Mesh(new THREE.TorusGeometry(0.135, 0.012, 8, 20), new THREE.MeshStandardMaterial({ color: 0xdfe9ff, roughness: 0.2 }));
      rim.rotation.x = Math.PI / 2; rim.position.y = height;
      const g = new THREE.Group(); g.add(shell, rim);
      const liquid = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.55, 1, 28), liquidMaterial('#5590c8'));
      liquid.userData.baseY = 0.05;
      g.add(liquid);
      return { shell: g, liquid, height, maxVol: 250 };
    }
    function buildTestTube(): { shell: THREE.Object3D; liquid: THREE.Mesh; height: number; maxVol: number } {
      const r = 0.26, height = 1.55;
      const pts: THREE.Vector2[] = [];
      for (let i = 0; i <= 8; i++) {
        const t = (i / 8) * Math.PI * 0.5;
        pts.push(new THREE.Vector2(Math.sin(t) * r, r - Math.cos(t) * r));
      }
      pts.push(new THREE.Vector2(r, height));
      const shell = new THREE.Mesh(new THREE.LatheGeometry(pts, 24), glassMaterial());
      shell.castShadow = true;
      const g = new THREE.Group(); g.add(shell);
      const liquid = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.85, r * 0.85, 1, 20), liquidMaterial('#5590c8'));
      liquid.userData.baseY = r + 0.02;
      g.add(liquid);
      return { shell: g, liquid, height, maxVol: 120 };
    }
    function buildCylinder(): { shell: THREE.Object3D; liquid: THREE.Mesh; height: number; maxVol: number } {
      const r = 0.24, height = 1.9;
      const shell = new THREE.Mesh(new THREE.CylinderGeometry(r, r, height, 24, 1, true), glassMaterial());
      shell.position.y = height / 2; shell.castShadow = true;
      const bottom = new THREE.Mesh(new THREE.CircleGeometry(r, 24), glassMaterial());
      bottom.rotation.x = -Math.PI / 2; bottom.position.y = 0.005;
      const g = new THREE.Group(); g.add(shell, bottom);
      for (let i = 1; i <= 4; i++) {
        const ring = new THREE.Mesh(new THREE.TorusGeometry(r + 0.005, 0.006, 6, 20), new THREE.MeshBasicMaterial({ color: 0x9fb8e0 }));
        ring.rotation.x = Math.PI / 2; ring.position.y = (height / 5) * i;
        g.add(ring);
      }
      const liquid = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.88, r * 0.88, 1, 20), liquidMaterial('#5590c8'));
      liquid.userData.baseY = 0.02;
      g.add(liquid);
      return { shell: g, liquid, height, maxVol: 190 };
    }
    function vesselBuilder(type: VesselType) {
      if (type === 'beaker') return buildBeaker();
      if (type === 'flask') return buildFlask();
      if (type === 'test_tube') return buildTestTube();
      return buildCylinder();
    }

    // ================= LAB STATE =================
    let vessels: Vessel[] = [];
    let vc = 0;
    let selId: string | null = null;
    let pourSrcId: string | null = null;
    const particles: Particle[] = [];
    let shakeMag = 0, shakeDur = 0, shakeStart = 0;

    function getEl(id: string) {
      return overlayRef.current?.querySelector('#' + id) as HTMLElement | null;
    }
    (window as any).log = (msg: string, type = '') => {
      const el = getEl('log'); if (!el) return;
      const d = document.createElement('div'); d.className = 'll ' + type;
      d.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`;
      el.prepend(d);
      while (el.children.length > 40) el.removeChild(el.lastChild as Node);
    };
    (window as any).showT = (msg: string, type = '') => {
      const t = document.createElement('div'); t.className = 'toast ' + type; t.textContent = msg;
      getEl('wb')?.appendChild(t); setTimeout(() => t.remove(), 2500);
    };

    function worldXForIndex(n: number) {
      const step = Math.min(2.6, 15 / Math.max(n, 1));
      let x = -7.5 + n * step;
      if (x > 8.4) x = -7 + Math.random() * 1.5;
      return x;
    }

    function makeVessel(type: VesselType, chemId: string | null, lbl: string) {
      const chem = chemId ? getChem(chemId) : null;
      const id = 'v' + (++vc);
      const built = vesselBuilder(type);
      const group = new THREE.Group();
      group.add(built.shell);
      const n = vessels.length;
      const x = worldXForIndex(n);
      const z = 0.1 + (Math.random() - 0.5) * 0.4;
      group.position.set(x, 0, z);
      benchGroup.add(group);

      const labelEl = document.createElement('div');
      labelEl.className = 'v-label';
      const labelObj = new CSS2DObject(labelEl);
      labelObj.position.set(0, built.height + 0.35, 0);
      group.add(labelObj);

      const v: Vessel = {
        id, type, chemId, label: chem ? chem.f : lbl, x, z,
        liq: chem ? chem.color : null, vol: chem ? 100 : 0, pH: chem ? chem.pH : 7, temp: 22,
        group, liquidMesh: built.liquid, liquidMat: built.liquid.material as THREE.MeshPhysicalMaterial,
        labelEl, labelObj, maxVol: built.maxVol, height: built.height,
      };
      vessels.push(v);
      selId = id;
      refreshVessel(v);
      updRP();
      (window as any).log(`${chem ? chem.f + ' (' + chem.n + ')' : lbl} qo'yildi`, 'i');
    }

    function refreshVessel(v: Vessel) {
      const frac = Math.max(0, Math.min(1, v.vol / v.maxVol));
      const fillH = Math.max(0.01, frac * (v.height - 0.08));
      const baseY = v.liquidMesh.userData.baseY ?? 0.02;
      v.liquidMesh.scale.y = fillH;
      v.liquidMesh.position.y = baseY + fillH / 2;
      if (v.liq) {
        v.liquidMat.color.set(v.liq.startsWith('rgba') ? '#88a8d0' : v.liq);
        v.liquidMat.visible = true;
        v.liquidMat.opacity = v.liq.startsWith('rgba') ? 0.35 : 0.92;
      } else {
        v.liquidMat.visible = false;
      }
      // gentle emissive tint on hot liquid
      const heatT = Math.max(0, Math.min(1, (v.temp - 22) / 250));
      v.liquidMat.emissive = new THREE.Color(heatT * 0.6, heatT * 0.15, 0);
      v.liquidMat.emissiveIntensity = heatT;

      v.labelEl.innerHTML = `

${v.label}

`+
        (v.vol > 0.5 ?`

${v.vol.toFixed(0)}ml${v.temp > 26 ? ' · ' + v.temp.toFixed(0) + '°C' : ''}

` : '');
v.labelEl.classList.toggle('sel', v.id === selId);
}

    function removeVessel(id: string) {
      const v = vessels.find(x => x.id === id);
      if (!v) return;
      benchGroup.remove(v.group);
      v.group.traverse(o => {
        const mesh = o as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
        if (mat) (Array.isArray(mat) ? mat : [mat]).forEach(m => m.dispose());
      });
      vessels = vessels.filter(x => x.id !== id);
      if (selId === id) selId = null;
      updRP();
    }
    (window as any).removeVessel = (id: string) => removeVessel(id);

    (window as any).resetLabState = () => {
      [...vessels].forEach(v => removeVessel(v.id));
      (window as any).log('Stol tozalandi', 'w');
      (window as any).showT('Stol tozalandi');
      updRP();
    };

    function updRP() {
      const body = getEl('rp-body');
      if (!body) return;
      vessels.forEach(v => v.labelEl.classList.toggle('sel', v.id === selId));
      const v = vessels.find(v => v.id === selId);
      if (!v) { body.innerHTML = '

Idish bosing yoki tanlang

'; return; }
const chem = v.chemId ? getChem(v.chemId) : null;
body.innerHTML = `

${v.type}: ${v.label}

Modda: ${chem ? chem.n : '—'}

Hajm: ${v.vol.toFixed(0)}ml

pH: ${v.pH.toFixed(1)}

Harorat: ${v.temp.toFixed(1)}°C

        Olib tashlash
      `;
      const btn = getEl('rp-remove');
      if (btn) btn.onclick = () => removeVessel(v.id);
    }

    // ---------- particles ----------
    function spawnParticle(kind: ParticleKind, pos: THREE.Vector3, opts: Partial & { color?: number } = {}) {
      const mat = new THREE.SpriteMaterial({
        map: glowTex, color: opts.color ?? 0xffffff, transparent: true, depthWrite: false,
        blending: kind === 'smoke' ? THREE.NormalBlending : THREE.AdditiveBlending,
        opacity: kind === 'smoke' ? 0.16 : 0.9,
      });
      const sprite = new THREE.Sprite(mat);
      const baseR = opts.baseR ?? (kind === 'bubble' ? 0.05 : kind === 'smoke' ? 0.35 : kind === 'flash' ? 0.1 : 0.4);
      sprite.scale.set(baseR, baseR, 1);
      sprite.position.copy(pos);
      scene.add(sprite);
      particles.push({
        type: kind, sprite, life: opts.maxLife ?? 1, maxLife: opts.maxLife ?? 1,
        vx: opts.vx ?? (Math.random() - 0.5) * 0.3, vy: opts.vy ?? (kind === 'bubble' ? 1.2 : kind === 'smoke' ? 0.6 : 0),
        vz: opts.vz ?? (Math.random() - 0.5) * 0.3, maxR: opts.maxR ?? baseR * (kind === 'flash' ? 12 : kind === 'fireball' ? 3 : 2),
        baseR,
      });
    }

    function doScreenShake(intensity: number, duration: number) {
      shakeMag = intensity; shakeDur = duration; shakeStart = performance.now();
    }
    function currentShake() {
      const elapsed = performance.now() - shakeStart;
      if (elapsed >= shakeDur) return { x: 0, y: 0 };
      const decay = 1 - elapsed / shakeDur;
      return { x: (Math.random() - 0.5) * shakeMag * decay, y: (Math.random() - 0.5) * shakeMag * decay };
    }

    function sExplosion(v: Vessel, big: boolean) {
      const pos = v.group.position.clone(); pos.y = v.height * 0.6;
      spawnParticle('flash', pos, { maxLife: 0.4, baseR: 0.2, maxR: big ? 5.5 : 3.2, color: 0xfff6d8 });
      const count = big ? 10 : 6;
      for (let i = 0; i < count; i++) {
        setTimeout(() => {
          spawnParticle('fireball', pos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 0.8, Math.random() * 0.6, (Math.random() - 0.5) * 0.8)), {
            maxLife: 0.9, baseR: big ? 0.55 : 0.35, maxR: big ? 1.6 : 1.0, vy: 1.4 + Math.random() * 1.2, color: 0xff5a10,
          });
        }, i * 45);
      }
      for (let i = 0; i < 14; i++) {
        spawnParticle('smoke', pos.clone(), { maxLife: 2.2, baseR: 0.3, maxR: 2.2, vy: 0.7 + Math.random() * 0.5, color: 0x777788 });
      }
      const flash = new THREE.PointLight(0xffb060, big ? 60 : 30, 12, 2);
      flash.position.copy(pos);
      scene.add(flash);
      let t = 0;
      const decayLight = () => {
        t += 1 / 60; flash.intensity = Math.max(0, (big ? 60 : 30) * (1 - t / 0.5));
        if (t < 0.5) requestAnimationFrame(decayLight); else scene.remove(flash);
      };
      decayLight();
      doScreenShake(big ? 0.35 : 0.16, big ? 900 : 600);
    }

    function applyRxn(tgt: Vessel, rxn: Rxn, amt: number) {
      tgt.liq = rxn.lc; tgt.pH = rxn.pH; tgt.vol = Math.min(tgt.maxVol, tgt.vol + amt);
      tgt.temp = Math.min(400, tgt.temp + (rxn.heat || 0));
      refreshVessel(tgt);
      (window as any).log(rxn.note, 's');

      if (rxn.eff.includes('bubble')) {
        for (let i = 0; i < 10; i++) {
          setTimeout(() => spawnParticle('bubble', tgt.group.position.clone().add(new THREE.Vector3((Math.random() - 0.5) * 0.3, 0.3, (Math.random() - 0.5) * 0.3)), {
            maxLife: 1.1, baseR: 0.05 + Math.random() * 0.05, vy: 0.9 + Math.random() * 0.6, color: 0xcfe8ff,
          }), i * 60);
        }
      }
      if (rxn.eff.includes('smoke')) {
        for (let i = 0; i < 8; i++) {
          setTimeout(() => spawnParticle('smoke', tgt.group.position.clone().add(new THREE.Vector3(0, tgt.height * 0.7, 0)), {
            maxLife: 1.8, baseR: 0.25, vy: 0.5, color: 0x9aa0b0,
          }), i * 90);
        }
      }
      if (rxn.eff.includes('precipitate')) {
        (window as any).showT('Cho\u2018kma hosil bo\u2018lmoqda…', 's');
      }
      if (rxn.eff === 'explosion' || rxn.eff === 'mega_explosion') {
        setTimeout(() => {
          sExplosion(tgt, rxn.eff === 'mega_explosion');
          (window as any).showT(rxn.eff === 'mega_explosion' ? '💥💥 MEGA PORTLASH!!' : '💥 PORTLASH!', 'e');
          removeVessel(tgt.id);
        }, 260);
      }
    }

    // pour animation: bezier stream between two vessels using a thin curved tube
    let pourAnim: { curve: THREE.QuadraticBezierCurve3; mesh: THREE.Mesh; t: number; done: () => void } | null = null;
    function startPour(from: Vessel, to: Vessel, color: string, done: () => void) {
      const sp = from.group.position.clone(); sp.y = from.height * 0.9;
      const tp = to.group.position.clone(); tp.y = to.height * 0.5;
      const mid = sp.clone().add(tp).multiplyScalar(0.5); mid.y += 1.6;
      const curve = new THREE.QuadraticBezierCurve3(sp, mid, tp);
      const geo = new THREE.TubeGeometry(curve, 24, 0.035, 8, false);
      const mat = new THREE.MeshBasicMaterial({ color: color.startsWith('rgba') ? 0x88a8d0 : new THREE.Color(color), transparent: true, opacity: 0.85 });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.scale.set(1, 0.001, 1); // reveal via morphing not trivial; use draw-range trick instead
      scene.add(mesh);
      pourAnim = { curve, mesh, t: 0, done };
    }
    function updatePour(dt: number) {
      if (!pourAnim) return;
      pourAnim.t += dt * 1.6;
      const reveal = Math.min(1, pourAnim.t);
      pourAnim.mesh.scale.set(1, 1, 1);
      (pourAnim.mesh.material as THREE.MeshBasicMaterial).opacity = 0.85 * Math.sin(Math.min(1, reveal) * Math.PI);
      if (pourAnim.t >= 1.3) {
        scene.remove(pourAnim.mesh);
        pourAnim.mesh.geometry.dispose();
        (pourAnim.mesh.material as THREE.Material).dispose();
        const cb = pourAnim.done; pourAnim = null; cb();
      }
    }

    function openPour(srcId: string, tgtId: string) {
      pourSrcId = srcId;
      const tgtSel = getEl('p-tgt') as HTMLSelectElement | null;
      if (!tgtSel) return;
      tgtSel.innerHTML = '';
      vessels.filter(v => v.id !== srcId).forEach(v => { tgtSel.innerHTML += `${v.label}`; });
      if (tgtId) tgtSel.value = tgtId;
      getEl('pour-modal')?.classList.add('show');
    }
    (window as any).doPourFromModal = () => {
      const tgtSel = getEl('p-tgt') as HTMLSelectElement | null;
      const amtInp = getEl('p-amt') as HTMLInputElement | null;
      const tgtId = tgtSel?.value; const amt = parseFloat(amtInp?.value || '50') || 50;
      getEl('pour-modal')?.classList.remove('show');
      const src = vessels.find(v => v.id === pourSrcId), tgt = vessels.find(v => v.id === tgtId);
      if (!src || !tgt || !src.liq) return;
      const actualAmt = Math.min(amt, src.vol);
      startPour(src, tgt, src.liq, () => {
        src.vol -= actualAmt; if (src.vol < 0.5) { src.liq = null; src.vol = 0; }
        refreshVessel(src);
        const rxn = findRxn(src.chemId, tgt.chemId);
        if (rxn) applyRxn(tgt, rxn, actualAmt);
        else {
          if (!tgt.liq) { tgt.liq = src.liq; tgt.vol = actualAmt; tgt.pH = src.pH; }
          else { tgt.pH = (src.pH + tgt.pH) / 2; tgt.liq = blendHex(src.liq!, tgt.liq); tgt.vol = Math.min(tgt.maxVol, tgt.vol + actualAmt); }
          refreshVessel(tgt);
        }
        updRP();
      });
    };
    (window as any).closePourModal = () => getEl('pour-modal')?.classList.remove('show');

    // ================= INTERACTION (raycasting) =================
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    const benchPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    let dragging: { v: Vessel; offset: THREE.Vector3 } | null = null;
    let pointerDownPos = { x: 0, y: 0 };

    function setPointer(e: PointerEvent) {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    }
    function pickVessel(): Vessel | null {
      raycaster.setFromCamera(pointer, camera);
      const objs = vessels.map(v => v.group);
      const hits = raycaster.intersectObjects(objs, true);
      if (!hits.length) return null;
      let obj: THREE.Object3D | null = hits[0].object;
      while (obj && !vessels.find(v => v.group === obj)) obj = obj.parent;
      return vessels.find(v => v.group === obj) || null;
    }
    function pickBurner(): boolean {
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObject(burnerGroup, true);
      return hits.length > 0;
    }
    function planeHit(): THREE.Vector3 | null {
      raycaster.setFromCamera(pointer, camera);
      const pt = new THREE.Vector3();
      return raycaster.ray.intersectPlane(benchPlane, pt) ? pt : null;
    }

    function onPointerDown(e: PointerEvent) {
      setPointer(e);
      pointerDownPos = { x: e.clientX, y: e.clientY };
      if (pickBurner()) {
        burnerOn = !burnerOn;
        (window as any).log(burnerOn ? '🔥 Pech yondirildi' : "Pech o'chirildi", burnerOn ? 'w' : 'i');
        (window as any).showT(burnerOn ? '🔥 Pech yondi!' : "Pech o'chdi");
        return;
      }
      const v = pickVessel();
      if (v) {
        selId = v.id; updRP();
        const hitPt = planeHit();
        const offset = hitPt ? hitPt.clone().sub(v.group.position) : new THREE.Vector3();
        dragging = { v, offset };
        controls.enabled = false;
      }
    }
    function onPointerMove(e: PointerEvent) {
      setPointer(e);
      if (dragging) {
        const pt = planeHit();
        if (pt) {
          const nx = THREE.MathUtils.clamp(pt.x - dragging.offset.x, -9, 9);
          const nz = THREE.MathUtils.clamp(pt.z - dragging.offset.z, -2, 2);
          dragging.v.group.position.x = nx;
          dragging.v.group.position.z = nz;
        }
        renderer.domElement.style.cursor = 'grabbing';
      } else {
        renderer.domElement.style.cursor = (pickVessel() || pickBurner()) ? 'pointer' : 'default';
      }
    }
    function onPointerUp(e: PointerEvent) {
      if (dragging) {
        const v = dragging.v;
        const moved = Math.hypot(e.clientX - pointerDownPos.x, e.clientY - pointerDownPos.y) > 6;
        if (moved && v.liq && v.vol > 0.5) {
          const near = vessels.find(o => o.id !== v.id && Math.abs(o.group.position.x - v.group.position.x) < 1.1 && Math.abs(o.group.position.z - v.group.position.z) < 1.1);
          if (near) openPour(v.id, near.id);
        }
        dragging = null;
        controls.enabled = true;
      }
    }
    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);

    // ================= SIDEBAR / EQUIPMENT LISTS =================
    const gridEl = getEl('equip-grid');
    if (gridEl) {
      gridEl.innerHTML = '';
      ([
        { type: 'beaker' as VesselType, lbl: 'Stakan', icon: '🧪' },
        { type: 'flask' as VesselType, lbl: 'Kolba', icon: '⚗' },
        { type: 'test_tube' as VesselType, lbl: 'Probirka', icon: '🧫' },
        { type: 'cylinder' as VesselType, lbl: 'Silindr', icon: '📏' },
      ]).forEach(e => {
        const btn = document.createElement('div');
        btn.className = 'eq-btn';
        btn.innerHTML = `${e.icon}${e.lbl}`;
        btn.onclick = () => makeVessel(e.type, null, e.lbl);
        gridEl.appendChild(btn);
      });
    }
    function buildList(list: Chem[], targetId: string) {
      const el = getEl(targetId);
      if (!el) return;
      el.innerHTML = '';
      list.forEach(c => {
        const b = document.createElement('div');
        b.className = 'cb';
        b.innerHTML = `${c.f}${c.cat}`;
        b.onclick = () => makeVessel('beaker', c.id, c.f);
        el.appendChild(b);
      });
    }
    buildList(CHEMS.acids, 'acids-list');
    buildList(CHEMS.bases, 'bases-list');
    buildList(CHEMS.others, 'others-list');

    // ================= RESIZE =================
    function onResize() {
      const w = W(), h = H();
      camera.aspect = w / h; camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
      composer.setSize(w, h);
      bloom.setSize(w, h);
    }
    const ro = new ResizeObserver(onResize);
    ro.observe(mount);
    onResize();

    // ================= MAIN LOOP =================
    let raf = 0;
    let last = performance.now();
    function animate(now: number) {
      raf = requestAnimationFrame(animate);
      const dt = Math.min(0.05, (now - last) / 1000); last = now;

      controls.update();
      updatePour(dt);

      // burner flame + heat
      const targetFlame = burnerOn ? 1 : 0;
      flameLight.intensity += (( burnerOn ? 3.4 : 0) - flameLight.intensity) * Math.min(1, dt * 6);
      const t = now / 1000;
      flameSprites.forEach((s, i) => {
        const m = s.material as THREE.SpriteMaterial;
        m.opacity += (targetFlame * (0.55 + 0.35 * Math.sin(t * 9 + i)) - m.opacity) * Math.min(1, dt * 8);
        const h = 0.55 + Math.sin(t * 6 + i * 1.3) * 0.15;
        s.scale.set(0.35 - i * 0.02, (0.55 + h) * targetFlame + 0.001, 1);
        s.position.set(Math.sin(t * 4 + i) * 0.05, 0.25 + i * 0.06, Math.cos(t * 3 + i) * 0.05);
      });

      vessels.forEach(v => {
        const onBurner = Math.abs(v.group.position.x - BRN.x) < 1.1 && Math.abs(v.group.position.z - BRN.z) < 1.1;
        if (onBurner && burnerOn) v.temp = Math.min(400, v.temp + dt * 35);
        else v.temp = Math.max(22, v.temp - dt * 5);
        refreshVessel(v);
      });

      // particles
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.life -= dt / p.maxLife;
        p.sprite.position.x += p.vx * dt;
        p.sprite.position.y += p.vy * dt;
        p.sprite.position.z += p.vz * dt;
        if (p.type === 'flash') {
          const grow = 1 - p.life;
          p.sprite.scale.set(p.baseR + grow * p.maxR, p.baseR + grow * p.maxR, 1);
        } else if (p.type === 'fireball' || p.type === 'smoke') {
          const s = p.baseR + (1 - p.life) * p.maxR;
          p.sprite.scale.set(s, s, 1);
        }
        (p.sprite.material as THREE.SpriteMaterial).opacity = Math.max(0, p.life) * (p.type === 'smoke' ? 0.16 : 0.9);
        if (p.life <= 0) {
          scene.remove(p.sprite);
          (p.sprite.material as THREE.Material).dispose();
          particles.splice(i, 1);
        }
      }

      const shake = currentShake();
      camera.position.x += shake.x * 0.02; camera.position.y += shake.y * 0.02;

      composer.render();
      labelRenderer.render(scene, camera);
    }
    raf = requestAnimationFrame(animate);

    // ================= CLEANUP =================
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('pointerup', onPointerUp);
      [...vessels].forEach(v => removeVessel(v.id));
      controls.dispose();
      renderer.dispose();
      mount.removeChild(renderer.domElement);
      mount.removeChild(labelRenderer.domElement);
      delete (window as any).doPourFromModal;
      delete (window as any).closePourModal;
      delete (window as any).removeVessel;
      delete (window as any).resetLabState;
      delete (window as any).log;
      delete (window as any).showT;
    };

}, []);

return (

      @keyframes fadeOut { 0%{opacity:1; transform:translate(-50%,0);} 80%{opacity:1;} 100%{opacity:0; transform:translate(-50%,-8px);} }
        .modal { position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); background:#0d1220; padding:14px; border-radius:10px; z-index:200; display:none; border:1px solid rgba(79,168,255,0.25); min-width:180px; }
        .modal.show { display:block; }
        .msel, .mamt { width:100%; padding:5px; background:#111827; border:1px solid rgba(255,255,255,0.08); color:#fff; border-radius:4px; margin-bottom:8px; margin-top:3px; font-size:9px; }
        .v-label { pointer-events:none; text-align:center; font-family:'Exo 2',sans-serif; transform:translate(-50%,-100%); white-space:nowrap; }
        .vlabel-f { font-size:11px; font-weight:600; color:#7ab8f5; text-shadow:0 0 6px rgba(0,0,0,0.9), 0 0 2px #000; }
        .v-label.sel .vlabel-f { color:#bfe0ff; }
        .vlabel-v { font-size:9px; font-family:'Share Tech Mono',monospace; color:#9fc4ee; text-shadow:0 0 4px rgba(0,0,0,0.9); }
        .backbtn { position:absolute; top:10px; left:10px; z-index:50; background:rgba(13,18,32,0.75); border:1px solid rgba(79,168,255,0.25); color:#9fc4ee; border-radius:6px; padding:6px 10px; font-size:10px; display:flex; align-items:center; gap:6px; cursor:pointer; backdrop-filter:blur(4px); }
        .backbtn:hover { border-color:#4fa8ff; color:#fff; }
        .hint { position:absolute; bottom:44px; left:8px; z-index:40; font-size:8px; color:#3a4a60; background:rgba(5,7,13,0.5); padding:4px 8px; border-radius:4px; }
      `}




        {/* Sidebar */}





Idishlar

Reaktivlar

Kislotalar

Ishqorlar

Boshqalar

             (window as any).resetLabState()}
              className="w-full py-1.5 bg-red-500/10 border border-red-500/20 rounded-md text-red-400 text-[7px] font-bold uppercase tracking-wider hover:bg-red-500/20 transition-all flex items-center justify-center gap-1.5 group"
            >
              ✕
              Tozalash








        {/* 3D Workspace */}






           navigateToHome()}>
             Bosh sahifa



Idishni sudrab boshqasiga yaqinlashtiring — quyish oynasi ochiladi. Sichqoncha bilan aylantiring/kattalashtiring.

Quyish

Qaysi idishga:

Miqdor (ml):

             (window as any).doPourFromModal()}>Quyish
             (window as any).closePourModal()}>Bekor qilish







        {/* Analysis */}





Tahlil

);
}

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/db6000a3-2d27-43f4-a270-aada592dec9e).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
